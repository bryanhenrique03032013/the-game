create table if not exists dlp_profiles (
  user_id text primary key,
  badge_name text not null default 'Detetive',
  selected_level text not null default 'iniciante',
  xp integer not null default 0,
  seen_briefing boolean not null default false,
  updated_at timestamptz not null default now()
);

create table if not exists dlp_cases (
  user_id text not null,
  level text not null,
  case_id text not null,
  completed boolean not null default false,
  stars integer not null default 0,
  best_score integer not null default 0,
  clue text,
  attempts integer not null default 0,
  last_ids text,
  updated_at timestamptz not null default now(),
  primary key (user_id, level, case_id)
);

create table if not exists dlp_certificates (
  user_id text not null,
  level text not null,
  issued_at timestamptz not null default now(),
  score integer not null default 0,
  primary key (user_id, level)
);

create index if not exists dlp_cases_user_idx on dlp_cases (user_id);
