import { o as __toESM } from "../_runtime.mjs";
import { V as require_react, x as require_jsx_runtime, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as levelLabel } from "./types-Tlg2m4nK.mjs";
import { _ as useCurrentUserState, a as LoadingDossier, c as RedirectToSignIn, d as Tape, o as PaperCard, p as TopBar, t as Btn, u as StationShell, v as useGame } from "./hub-D8PQ6Lwz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/diploma-BTGkS50N.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DiplomaScreen() {
	const navigate = useNavigate();
	const profile = useGame((s) => s.profile);
	const date = (/* @__PURE__ */ new Date()).toLocaleDateString("pt-BR");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StationShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, { profile }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tape, { className: "mb-6 h-6 -rotate-1" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperCard, {
			rotate: true,
			className: "mx-auto max-w-xl border-[10px] border-double border-ink/20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-center text-xs uppercase tracking-[0.28em] text-stamp",
					children: "Delegacia da Língua Portuguesa"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 text-center font-display text-3xl sm:text-4xl",
					children: "Certificado"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-center font-display text-lg text-ink/70",
					children: "Policial da Língua Portuguesa Nota 1000"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "wanted-stamp mx-auto mt-5 w-fit px-4 py-2 text-xl",
					children: "Aprovado"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-6 text-center text-sm leading-relaxed text-ink/80",
					children: [
						"Confere-se a ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-lg text-ink",
							children: profile.badgeName
						}),
						" o título de detetive do plantão ",
						levelLabel(profile.level),
						", por reunir as pistas de Anne, Bryan, Bedin e Lívia e reconstruir o parágrafo com conectivos."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex justify-between border-t border-ink/15 pt-4 text-xs uppercase tracking-[0.14em] text-ink/50",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Chefe Manuella" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: date }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [profile.certificateScore || profile.xp, " pts"] })
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto mt-6 flex max-w-xl flex-col gap-2 sm:flex-row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				className: "flex-1",
				variant: "paper",
				onClick: () => navigate({ to: "/" }),
				children: "Voltar à delegacia"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				className: "flex-1",
				variant: "ghost",
				onClick: () => navigate({
					to: "/caso/$slug",
					params: { slug: "manuella" }
				}),
				children: "Reabrir o caso final"
			})]
		})
	] });
}
function DiplomaPage() {
	const { user, isPending } = useCurrentUserState();
	const { ready, hydrate } = useGame();
	(0, import_react.useEffect)(() => {
		if (user) hydrate();
	}, [user, hydrate]);
	if (isPending || user && !ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingDossier, {});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DiplomaScreen, {});
}
//#endregion
export { DiplomaPage as component };
