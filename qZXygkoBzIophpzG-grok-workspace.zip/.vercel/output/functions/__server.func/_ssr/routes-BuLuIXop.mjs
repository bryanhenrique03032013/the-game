import { o as __toESM } from "../_runtime.mjs";
import { V as require_react, x as require_jsx_runtime, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as useCurrentUserState, a as LoadingDossier, f as TitleScreen, g as unlockAudio, r as HubScreen, v as useGame } from "./hub-D8PQ6Lwz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BuLuIXop.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const navigate = useNavigate();
	const { user, isPending } = useCurrentUserState();
	const { ready, hydrate, error } = useGame();
	(0, import_react.useEffect)(() => {
		if (user) hydrate();
	}, [user, hydrate]);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingDossier, {});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TitleScreen, { onEnter: () => {
		unlockAudio();
		navigate({ to: "/login" });
	} });
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingDossier, {});
	if (error === "Unauthorized") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TitleScreen, { onEnter: () => {
		unlockAudio();
		navigate({ to: "/login" });
	} });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HubScreen, {});
}
//#endregion
export { Home as component };
