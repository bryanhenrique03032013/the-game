import { o as __toESM } from "../_runtime.mjs";
import { V as require_react, v as Navigate, x as require_jsx_runtime, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as GROK_PROVIDERS } from "./server-DYyuqnvB.mjs";
import { r as signIn, t as authClient } from "./client-B40BzJxt.mjs";
import { _ as useCurrentUserState, a as LoadingDossier, d as Tape, i as Input, n as Field, o as PaperCard, t as Btn, u as StationShell } from "./hub-D8PQ6Lwz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-B5wAPcqI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Login() {
	const navigate = useNavigate();
	const { user, isPending } = useCurrentUserState();
	const [mode, setMode] = (0, import_react.useState)("in");
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingDossier, {});
	if (user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/" });
	async function onSubmit(event) {
		event.preventDefault();
		setBusy(true);
		setError(null);
		try {
			if (mode === "up") {
				const res = await authClient.signUp.email({
					email,
					password,
					name: name.trim() || "Detetive"
				});
				if (res.error) throw new Error(res.error.message);
			} else {
				const res = await authClient.signIn.email({
					email,
					password
				});
				if (res.error) throw new Error(res.error.message);
			}
			navigate({ to: "/" });
		} catch (err) {
			const message = err instanceof Error ? err.message : "Não foi possível identificar o crachá.";
			setError(translateAuthError(message));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StationShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tape, { className: "mb-8 h-6 -rotate-2" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-xs tracking-[0.3em] text-tape",
			children: "IDENTIFIQUE-SE"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-4xl",
			children: "Balcão da delegacia"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 max-w-md text-sm text-paper/70",
			children: "Crie um crachá com e-mail ou entre com Google / X. O progresso das salas fica salvo na sua conta."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperCard, {
			className: "mt-6 max-w-md",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2",
					children: GROK_PROVIDERS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "ink",
						className: "flex-1",
						onClick: () => signIn(p.providerId, { callbackURL: "/" }),
						children: p.label
					}, p.providerId))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "my-4 text-center text-xs uppercase tracking-[0.18em] text-ink/40",
					children: "ou e-mail da casa"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "space-y-3",
					onSubmit,
					children: [
						mode === "up" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Nome no crachá",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: name,
								onChange: (e) => setName(e.target.value),
								autoComplete: "name",
								required: true
							})
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "E-mail",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "email",
								value: email,
								onChange: (e) => setEmail(e.target.value),
								autoComplete: "email",
								required: true
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Senha",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "password",
								value: password,
								onChange: (e) => setPassword(e.target.value),
								autoComplete: mode === "up" ? "new-password" : "current-password",
								minLength: 8,
								required: true
							})
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-stamp",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							type: "submit",
							variant: "stamp",
							className: "w-full",
							disabled: busy,
							children: busy ? "Conferindo…" : mode === "up" ? "Criar crachá" : "Entrar no plantão"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-4 w-full text-sm text-ink/60 underline-offset-4 hover:underline",
					onClick: () => {
						setMode(mode === "up" ? "in" : "up");
						setError(null);
					},
					children: mode === "up" ? "Já tenho crachá" : "Ainda não tenho crachá"
				})
			] })
		})
	] });
}
function translateAuthError(message) {
	const lower = message.toLowerCase();
	if (lower.includes("invalid") && lower.includes("password")) return "E-mail ou senha não conferem.";
	if (lower.includes("already") || lower.includes("exists")) return "Esse e-mail já tem crachá. Entre no plantão.";
	if (lower.includes("too short") || lower.includes("min")) return "A senha precisa de pelo menos 8 caracteres.";
	return message;
}
//#endregion
export { Login as component };
