import { o as __toESM } from "../_runtime.mjs";
import { V as require_react, _ as Link, v as Navigate, x as require_jsx_runtime, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { a as emptyProfile, i as authMiddleware, o as levelLabel, r as LEVELS, s as rankForXp, t as CASES } from "./types-Tlg2m4nK.mjs";
import { a as hasGateSessionMarker } from "./server-DYyuqnvB.mjs";
import { i as Search, r as Shield, s as Lock } from "../_libs/lucide-react.mjs";
import { i as signOut, t as authClient } from "./client-B40BzJxt.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hub-D8PQ6Lwz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	const { data, isPending } = authClient.useSession();
	const user = data?.user;
	return {
		user: user ? {
			id: user.id,
			displayName: user.name ?? null,
			primaryEmail: user.email ?? null,
			profileImageUrl: user.image ?? null,
			isDevFallback: false
		} : null,
		isPending
	};
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Auth state components — plain wrappers around `useCurrentUserState()`.
*
* With auth on, visitors are signed out until they authenticate — in the sandbox
* live preview too, which does real sign-in. The shared dev user appears only
* when auth is disabled (`VITE_AUTH_ENABLED=false`, the shipped default).
* While the session is still resolving, gates that care about signed-out state
* render nothing so there's no signed-out flash on hard reload.
*/
/** Where `RedirectToSignIn` sends signed-out visitors. Create this route. */
var SIGN_IN_PATH = "/login";
/**
* Client-side redirect to the sign-in route (TanStack `<Navigate>` — NOT a full
* `window.location` reload). A hard navigation re-bootstraps the SPA and re-runs
* session loading, which feels like a second "Loading…" on /login.
*
* Guard routes by waiting out `isPending` first (see `use-current-user`), then
* render this.
*/
function RedirectToSignIn({ to = SIGN_IN_PATH }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to });
}
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getProfile = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("02922f4e6fbfc588b9e0b8e37e22d430634f8d962f9c7b2bb69d5549ea47434d"));
var updateProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("139adf732e4e8dd4bc409f0f58dec4cea4a6e1c9e260aa6dc367bc5251b9f6ed"));
var saveCaseResult = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("a337602b5c90162e891b79c35e573084737cf1c21d7e320628574871a1551c00"));
var issueCertificate = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("8e7234c66de85193ce96716f97f0a84cac7555efcc10fa6eed1e40565a73737d"));
var useGame = create((set, get) => ({
	profile: emptyProfile(),
	ready: false,
	error: null,
	async hydrate() {
		try {
			set({
				profile: await getProfile(),
				ready: true,
				error: null
			});
		} catch (err) {
			set({
				error: err instanceof Error ? err.message : "Falha ao abrir o dossiê.",
				ready: true
			});
		}
	},
	async setBadge(badgeName) {
		set({ profile: await updateProfile({ data: { badgeName } }) });
	},
	async setLevel(level) {
		set({ profile: await updateProfile({ data: { level } }) });
	},
	async markBriefing() {
		set({ profile: await updateProfile({ data: { seenBriefing: true } }) });
	},
	async finishCase(input) {
		const { profile } = get();
		set({ profile: await saveCaseResult({ data: {
			...input,
			level: profile.level
		} }) });
	},
	async certify(score) {
		const { profile } = get();
		set({ profile: await issueCertificate({ data: {
			level: profile.level,
			score
		} }) });
	}
}));
var ctx = null;
function getCtx() {
	if (typeof window === "undefined") return null;
	if (!ctx) {
		const Ctor = window.AudioContext || window.webkitAudioContext;
		if (!Ctor) return null;
		ctx = new Ctor();
	}
	return ctx;
}
function unlockAudio() {
	const audio = getCtx();
	if (!audio) return;
	if (audio.state === "suspended") audio.resume();
}
function beep(freq, dur, type, gain = .05, delay = 0) {
	const audio = getCtx();
	if (!audio) return;
	const now = audio.currentTime + delay;
	const osc = audio.createOscillator();
	const g = audio.createGain();
	osc.type = type;
	osc.frequency.setValueAtTime(freq, now);
	g.gain.setValueAtTime(gain, now);
	g.gain.exponentialRampToValueAtTime(1e-4, now + dur);
	osc.connect(g);
	g.connect(audio.destination);
	osc.start(now);
	osc.stop(now + dur + .02);
}
var sfx = {
	stamp() {
		beep(90, .12, "square", .07);
		beep(180, .08, "triangle", .04, .04);
	},
	ok() {
		beep(520, .08, "triangle", .05);
		beep(740, .1, "triangle", .04, .07);
	},
	bad() {
		beep(180, .14, "sawtooth", .04);
	},
	tick() {
		beep(420, .03, "square", .025);
	},
	win() {
		beep(523, .1, "triangle", .05);
		beep(659, .1, "triangle", .05, .1);
		beep(784, .16, "triangle", .05, .2);
	}
};
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Tape({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("crime-tape h-7 w-[140%] max-w-none shadow-[0_8px_16px_rgba(0,0,0,0.35)]", className),
		"aria-hidden": "true"
	});
}
function StationShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "station-bg relative min-h-dvh overflow-x-hidden text-paper",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-x-0 top-0 h-24 bg-[linear-gradient(180deg,rgba(0,0,0,0.45),transparent)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative mx-auto w-full max-w-5xl px-4 pb-16 pt-[max(1rem,env(safe-area-inset-top))] sm:px-6",
			children
		})]
	});
}
function TopBar({ profile }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "mb-6 flex items-start justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/",
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xs tracking-[0.28em] text-tape",
				children: "D.L.P."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate font-display text-lg text-paper",
				children: "Delegacia da Língua"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex shrink-0 items-center gap-3 rounded-[28px] border border-paper/15 bg-ink-2/80 px-3 py-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hidden text-right sm:block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-sm leading-tight",
					children: profile.badgeName
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-paper/60",
					children: [
						rankForXp(profile.xp),
						" · ",
						levelLabel(profile.level),
						" · ",
						profile.xp,
						" XP"
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-paper [&_button]:text-paper/70 [&_span]:text-paper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})
			})]
		})]
	});
}
function PaperCard({ children, className, rotate }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("paper-grain paper-enter text-ink rounded-[28px] p-4 shadow-[0_18px_40px_rgba(0,0,0,0.35)] sm:p-6", rotate && "rotate-[-0.4deg]", className),
		children
	});
}
function Btn({ children, onClick, type = "button", variant = "paper", className, disabled }) {
	const styles = {
		paper: "bg-paper text-ink hover:bg-paper-2",
		stamp: "bg-stamp text-paper hover:bg-stamp-2",
		ghost: "bg-transparent text-paper border border-paper/25 hover:bg-paper/10",
		ink: "bg-ink text-paper hover:bg-ink-3 border border-ink-3"
	}[variant];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		disabled,
		onClick,
		className: cn("inline-flex min-h-11 items-center justify-center rounded-xl px-4 py-2.5 text-center font-medium transition-transform duration-[150ms] ease-[cubic-bezier(0.22,1,0.36,1)] active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50", styles, className),
		children
	});
}
function StampFlash({ text, show }) {
	if (!show) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none fixed inset-0 z-50 grid place-items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "stamp-pop wanted-stamp rounded-md px-7 py-4 text-4xl",
			children: text
		})
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-medium uppercase tracking-[0.16em] text-ink/55",
			children: label
		}), children]
	});
}
function Input(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		...props,
		className: cn("h-11 w-full rounded-lg border border-ink/15 bg-paper px-3 text-ink outline-none ring-stamp/0 transition focus:border-stamp focus:ring-2 focus:ring-stamp/30", props.className)
	});
}
function ProgressDots({ current, total }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex gap-1.5",
		"aria-label": `Pista ${current} de ${total}`,
		children: Array.from({ length: total }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-1.5 flex-1 rounded-full", i < current ? "bg-stamp" : "bg-ink/15") }, i))
	});
}
function HubScreen() {
	const navigate = useNavigate();
	const { profile, setLevel, setBadge, markBriefing } = useGame();
	const [name, setName] = (0, import_react.useState)(profile.badgeName);
	const [savingName, setSavingName] = (0, import_react.useState)(false);
	const lockedFinal = !CASES[4].lockedUntil?.every((id) => profile.cases[id].completed);
	(0, import_react.useEffect)(() => {
		setName(profile.badgeName);
	}, [profile.badgeName]);
	async function saveName() {
		setSavingName(true);
		await setBadge(name);
		setSavingName(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StationShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, { profile }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative overflow-hidden rounded-[32px] border border-paper/10 bg-ink-2 px-5 py-6 sm:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tape, { className: "absolute -left-6 top-5 h-6 rotate-[-3deg] opacity-90" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tape, { className: "absolute -right-10 bottom-6 h-5 rotate-[4deg] opacity-70" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "relative font-display text-xs tracking-[0.28em] text-tape",
					children: "CENA DO CRIME"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "relative mt-3 max-w-xl font-display text-3xl leading-tight sm:text-4xl",
					children: "Quatro salas. Um gabinete. A língua portuguesa sob investigação."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "relative mt-3 max-w-lg text-sm text-paper/70",
					children: [
						rankForXp(profile.xp),
						" ",
						profile.badgeName,
						", nível ",
						levelLabel(profile.level),
						". Prenda os erros, colete as pistas e peça o carimbo da chefe Manuella."
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 grid gap-3 sm:grid-cols-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperCard, {
				className: "sm:col-span-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.16em] text-ink/50",
						children: "Seleção de nível"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid grid-cols-3 gap-2",
						children: LEVELS.map((level) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								unlockAudio();
								sfx.tick();
								setLevel(level);
							},
							className: cn("min-h-11 rounded-xl border px-2 py-3 font-display text-sm", profile.level === level ? "border-stamp bg-stamp text-paper" : "border-ink/15 bg-paper-2 text-ink hover:border-ink/40"),
							children: levelLabel(level)
						}, level))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-ink/55",
						children: "Iniciante: 5 frases. Intermediário: 7. Avançado: 10 no mural da Anne, com Enem no gabinete. As perguntas mudam a cada entrada na sala."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperCard, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Nome no crachá",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: name,
					maxLength: 32,
					onChange: (e) => setName(e.target.value)
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				className: "mt-3 w-full",
				variant: "ink",
				disabled: savingName,
				onClick: saveName,
				children: savingName ? "Gravando…" : "Atualizar crachá"
			})] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 grid gap-3 sm:grid-cols-2",
			children: CASES.map((meta) => {
				const progress = profile.cases[meta.id];
				const locked = meta.id === "manuella" && lockedFinal;
				const cardClass = cn("block rounded-[28px] border p-5 transition", locked ? "cursor-not-allowed border-tape/40 bg-ink-2/80 text-paper/70" : progress.completed ? "border-paper/20 bg-ink-3 text-paper hover:border-paper/40" : "border-paper/15 bg-ink-2 text-paper hover:border-tape/50");
				const body = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase tracking-[0.18em] text-tape",
								children: meta.desk
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 font-display text-2xl",
								children: meta.detective
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-paper/70",
								children: meta.title
							})
						] }), locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-5 text-tape" }) : progress.completed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-5 text-paper" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-5 text-tape" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-paper/65",
						children: meta.crime
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-center justify-between text-xs uppercase tracking-[0.14em]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: locked ? "Traga 4 pistas" : progress.completed ? "Pista arquivada" : "Abrir sala" }), progress.completed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-tape",
							children: [progress.stars, "/3"]
						}) : null]
					})
				] });
				if (locked) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cardClass,
					children: body
				}, meta.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/caso/$slug",
					params: { slug: meta.id },
					onClick: () => unlockAudio(),
					className: cardClass,
					children: body
				}, meta.id);
			})
		}),
		profile.certified ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				variant: "paper",
				className: "w-full",
				onClick: () => navigate({ to: "/diploma" }),
				children: "Ver certificado Nota 1000"
			})
		}) : null,
		!profile.seenBriefing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefing, { onDone: () => void markBriefing() }) : null
	] });
}
function Briefing({ onDone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-40 grid place-items-end bg-ink/70 p-4 sm:place-items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PaperCard, {
			className: "w-full max-w-lg rotate-[-0.6deg]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-[0.2em] text-stamp",
					children: "Chefe Manuella"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-display text-2xl",
					children: "Plantão da língua"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-relaxed text-ink/80",
					children: "Recruta, a delegacia está lotada de frases foragidas. Anne cuida da concordância. Bryan caça fake news. Bedin vasculha o quadro-negro. Lívia reconstitui a pontuação. Quando as quatro pistas estiverem na mesa, você monta o parágrafo do Enem — com conectivos — e leva o certificado de Policial da Língua Portuguesa Nota 1000."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					className: "mt-5 w-full",
					variant: "stamp",
					onClick: onDone,
					children: "Assinar o crachá e entrar"
				})
			]
		})
	});
}
function TitleScreen({ onEnter }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StationShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-[calc(100dvh-4rem)] flex-col justify-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tape, { className: "mb-8 h-7 -rotate-2" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-sm tracking-[0.4em] text-tape",
				children: "ERRO GRAMATICAL · CENA DO CRIME"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-4 font-display text-5xl leading-[0.95] sm:text-7xl",
				children: "D.L.P."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-display text-2xl text-paper/85 sm:text-3xl",
				children: "Delegacia da Língua"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-md text-sm text-paper/70",
				children: "RPG de plantão: crachá de detetive, fita zebrada, lupas de papelão e frases foragidas. Salve o progresso na sua conta e escolha o nível antes de abrir as salas."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-col gap-3 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "paper",
					className: "sm:min-w-48",
					onClick: onEnter,
					children: "Apresentar-se"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "/login",
					className: "inline-flex min-h-11 items-center justify-center rounded-xl border border-paper/25 px-4 text-sm text-paper",
					children: "Já tenho crachá"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-3 sm:grid-cols-3",
				children: [
					["Anne", "Concordância"],
					["Bryan", "Fake news"],
					["Bedin", "Ortografia"],
					["Lívia", "Pontuação"],
					["Manuella", "Caso final"]
				].map(([who, job]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-paper/10 bg-ink-2 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg",
						children: who
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.14em] text-paper/50",
						children: job
					})]
				}, who))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tape, { className: "mt-10 h-6 rotate-2" })
		]
	}) });
}
function LoadingDossier() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StationShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-[70dvh] place-items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-sm rounded-[28px] border border-paper/10 bg-ink-2 p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-24 animate-pulse rounded bg-paper/20" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-4 h-8 w-48 animate-pulse rounded bg-paper/15" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-6 h-24 animate-pulse rounded-2xl bg-paper/10" })
			]
		})
	}) });
}
//#endregion
export { useCurrentUserState as _, LoadingDossier as a, RedirectToSignIn as c, Tape as d, TitleScreen as f, unlockAudio as g, sfx as h, Input as i, StampFlash as l, cn as m, Field as n, PaperCard as o, TopBar as p, HubScreen as r, ProgressDots as s, Btn as t, StationShell as u, useGame as v };
