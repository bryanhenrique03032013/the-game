import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { a as emptyProfile, i as authMiddleware, n as CASE_IDS } from "./types-Tlg2m4nK.mjs";
import { r as getSql } from "./db-QVp0pp2e.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/progress-Pqrac4G5.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function asLevel(value) {
	if (value === "intermediario" || value === "avancado") return value;
	return "iniciante";
}
function asCaseId(value) {
	return CASE_IDS.includes(value) ? value : null;
}
function assemble(profile, cases, cert) {
	const next = emptyProfile(profile.badge_name);
	next.level = asLevel(profile.selected_level);
	next.xp = Number(profile.xp) || 0;
	next.seenBriefing = Boolean(profile.seen_briefing);
	next.certified = Boolean(cert);
	next.certificateScore = cert ? Number(cert.score) || 0 : 0;
	for (const row of cases) {
		const id = asCaseId(row.case_id);
		if (!id) continue;
		next.cases[id] = {
			completed: Boolean(row.completed),
			stars: Number(row.stars) || 0,
			bestScore: Number(row.best_score) || 0,
			clue: row.clue,
			attempts: Number(row.attempts) || 0
		};
	}
	return next;
}
async function readProfile(userId, level) {
	const sql = await getSql();
	let profiles = await sql`
    select badge_name, selected_level, xp, seen_briefing
    from dlp_profiles
    where user_id = ${userId}
  `;
	if (!profiles[0]) {
		await sql`
      insert into dlp_profiles (user_id, badge_name, selected_level)
      values (${userId}, ${"Detetive"}, ${level})
    `;
		profiles = await sql`
      select badge_name, selected_level, xp, seen_briefing
      from dlp_profiles
      where user_id = ${userId}
    `;
	}
	const row = profiles[0];
	const selected = asLevel(row.selected_level);
	return assemble(row, await sql`
    select case_id, completed, stars, best_score, clue, attempts
    from dlp_cases
    where user_id = ${userId} and level = ${selected}
  `, (await sql`
    select score from dlp_certificates
    where user_id = ${userId} and level = ${selected}
  `)[0]);
}
var getProfile_createServerFn_handler = createServerRpc({
	id: "02922f4e6fbfc588b9e0b8e37e22d430634f8d962f9c7b2bb69d5549ea47434d",
	name: "getProfile",
	filename: "src/lib/progress.ts"
}, (opts) => getProfile.__executeServer(opts));
var getProfile = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getProfile_createServerFn_handler, async ({ context }) => {
	return readProfile(context.userId, "iniciante");
});
var updateProfile_createServerFn_handler = createServerRpc({
	id: "139adf732e4e8dd4bc409f0f58dec4cea4a6e1c9e260aa6dc367bc5251b9f6ed",
	name: "updateProfile",
	filename: "src/lib/progress.ts"
}, (opts) => updateProfile.__executeServer(opts));
var updateProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(updateProfile_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const current = await readProfile(context.userId, "iniciante");
	const badgeName = (data.badgeName ?? current.badgeName).trim().slice(0, 32) || "Detetive";
	const level = data.level ?? current.level;
	const seen = data.seenBriefing ?? current.seenBriefing;
	await sql`
      insert into dlp_profiles (user_id, badge_name, selected_level, xp, seen_briefing, updated_at)
      values (${context.userId}, ${badgeName}, ${level}, ${current.xp}, ${seen}, now())
      on conflict (user_id) do update set
        badge_name = excluded.badge_name,
        selected_level = excluded.selected_level,
        seen_briefing = excluded.seen_briefing,
        updated_at = now()
    `;
	return readProfile(context.userId, level);
});
var saveCaseResult_createServerFn_handler = createServerRpc({
	id: "a337602b5c90162e891b79c35e573084737cf1c21d7e320628574871a1551c00",
	name: "saveCaseResult",
	filename: "src/lib/progress.ts"
}, (opts) => saveCaseResult.__executeServer(opts));
var saveCaseResult = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveCaseResult_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const current = await readProfile(context.userId, data.level);
	const prev = current.cases[data.caseId];
	const stars = Math.max(prev.stars, Math.min(3, Math.max(0, data.stars)));
	const bestScore = Math.max(prev.bestScore, data.score);
	const attempts = prev.attempts + 1;
	const completed = prev.completed || data.completed;
	const clue = data.clue || prev.clue;
	const xpGain = prev.completed ? Math.min(data.xpGain, 20) : data.xpGain;
	const xp = current.xp + Math.max(0, xpGain);
	await sql`
      insert into dlp_cases (
        user_id, level, case_id, completed, stars, best_score, clue, attempts, updated_at
      )
      values (
        ${context.userId}, ${data.level}, ${data.caseId}, ${completed}, ${stars},
        ${bestScore}, ${clue}, ${attempts}, now()
      )
      on conflict (user_id, level, case_id) do update set
        completed = excluded.completed,
        stars = excluded.stars,
        best_score = excluded.best_score,
        clue = excluded.clue,
        attempts = excluded.attempts,
        updated_at = now()
    `;
	await sql`
      insert into dlp_profiles (user_id, badge_name, selected_level, xp, seen_briefing, updated_at)
      values (${context.userId}, ${current.badgeName}, ${data.level}, ${xp}, ${current.seenBriefing}, now())
      on conflict (user_id) do update set
        xp = excluded.xp,
        selected_level = excluded.selected_level,
        updated_at = now()
    `;
	return readProfile(context.userId, data.level);
});
var issueCertificate_createServerFn_handler = createServerRpc({
	id: "8e7234c66de85193ce96716f97f0a84cac7555efcc10fa6eed1e40565a73737d",
	name: "issueCertificate",
	filename: "src/lib/progress.ts"
}, (opts) => issueCertificate.__executeServer(opts));
var issueCertificate = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(issueCertificate_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`
      insert into dlp_certificates (user_id, level, score, issued_at)
      values (${context.userId}, ${data.level}, ${data.score}, now())
      on conflict (user_id, level) do update set
        score = greatest(dlp_certificates.score, excluded.score)
    `;
	return readProfile(context.userId, data.level);
});
//#endregion
export { getProfile_createServerFn_handler, issueCertificate_createServerFn_handler, saveCaseResult_createServerFn_handler, updateProfile_createServerFn_handler };
