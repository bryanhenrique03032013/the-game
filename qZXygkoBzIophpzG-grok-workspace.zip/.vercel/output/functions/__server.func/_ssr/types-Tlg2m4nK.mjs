import { n as createMiddleware } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/types-Tlg2m4nK.js
/**
* Auth middleware for server functions — the standard way to get the caller's
* verified user id. When deployed the session cookie is same-origin and rides
* along automatically. In the live preview the client also forwards the bearer
* token (partitioned cookies) via the `.client` hook below — call sites do not
* thread it themselves.
*
*   import { createServerFn } from "@tanstack/react-start";
*   import { getSql } from "@/lib/db";
*   import { authMiddleware } from "@/lib/auth/middleware";
*
*   export const listTodos = createServerFn({ method: "GET" })
*     .middleware([authMiddleware])
*     .handler(async ({ context }) => {
*       const sql = await getSql();
*       return sql`select * from todos where user_id = ${context.userId}`;
*     });
*
* Signed out with auth on (live preview included) -> throws `UnauthorizedError`
* (see `verify.server.ts`). With auth disabled (`VITE_AUTH_ENABLED=false`, the
* shipped default) it resolves the shared dev user — but throws instead when a
* `DATABASE_URL` is also set, so an app without sign-in must not use this at
* all. On the auth-on path, use it on every server function that touches
* per-user data and scope every query by `context.userId`.
*/
var authMiddleware = createMiddleware({ type: "function" }).client(async ({ next }) => {
	const { getBearerToken } = await import("./client-B40BzJxt.mjs").then((n) => n.n).then((n) => n.n);
	return next({ sendContext: { bearerToken: getBearerToken() ?? void 0 } });
}).server(async ({ next, context }) => {
	const { assertSameSiteRequest } = await import("./isolation.server-CGNg1r0B.mjs");
	const { requireUserId } = await import("./verify.server-DXaT1FSC.mjs");
	assertSameSiteRequest();
	return next({ context: { userId: await requireUserId(context.bearerToken) } });
});
var LEVELS = [
	"iniciante",
	"intermediario",
	"avancado"
];
var CASE_IDS = [
	"anne",
	"bryan",
	"bedin",
	"livia",
	"manuella"
];
var CASES = [
	{
		id: "anne",
		detective: "Anne",
		title: "Detetive da Concordância",
		crime: "Frases com erro de concordância e transitividade",
		desk: "Sala 1 · Lupa e mural de frases"
	},
	{
		id: "bryan",
		detective: "Bryan",
		title: "Detetive do Fake News",
		crime: "Notícia sem fonte, argumento ou data",
		desk: "Sala 2 · Jornal de parede"
	},
	{
		id: "bedin",
		detective: "Bedin",
		title: "Detetive Ortográfico",
		crime: "Palavras escritas errado no meio do texto",
		desk: "Sala 3 · Quadro-negro e caça-palavras"
	},
	{
		id: "livia",
		detective: "Lívia",
		title: "Detetive da Pontuação",
		crime: "Vírgulas, crases e pontos desaparecidos",
		desk: "Sala 4 · Máquina de escrever"
	},
	{
		id: "manuella",
		detective: "Manuella",
		title: "Chefe da Delegacia",
		crime: "Redação sem conectivos — o caso final",
		desk: "Gabinete · Carimbo APROVADO",
		lockedUntil: [
			"anne",
			"bryan",
			"bedin",
			"livia"
		]
	}
];
function emptyCase() {
	return {
		completed: false,
		stars: 0,
		bestScore: 0,
		clue: null,
		attempts: 0
	};
}
function emptyProfile(badgeName = "Detetive") {
	return {
		badgeName,
		level: "iniciante",
		xp: 0,
		seenBriefing: false,
		cases: {
			anne: emptyCase(),
			bryan: emptyCase(),
			bedin: emptyCase(),
			livia: emptyCase(),
			manuella: emptyCase()
		},
		certified: false,
		certificateScore: 0
	};
}
function levelLabel(level) {
	if (level === "iniciante") return "Iniciante";
	if (level === "intermediario") return "Intermediário";
	return "Avançado";
}
function rankForXp(xp) {
	if (xp >= 700) return "Delegado adjunto";
	if (xp >= 450) return "Inspetor";
	if (xp >= 250) return "Detetive";
	if (xp >= 100) return "Detetive júnior";
	return "Recruta";
}
function roundCount(level, kind) {
	if (kind === "anne") {
		if (level === "iniciante") return 5;
		if (level === "intermediario") return 7;
		return 10;
	}
	if (kind === "bryan") {
		if (level === "iniciante") return 2;
		if (level === "intermediario") return 3;
		return 4;
	}
	if (kind === "bedin") {
		if (level === "iniciante") return 4;
		if (level === "intermediario") return 5;
		return 6;
	}
	if (level === "iniciante") return 4;
	if (level === "intermediario") return 6;
	return 8;
}
function xpFor(level, first, stars) {
	const base = level === "iniciante" ? 40 : level === "intermediario" ? 60 : 80;
	const bonus = stars >= 3 ? 15 : stars === 2 ? 8 : 0;
	return Math.round((first ? base : base / 2) + bonus);
}
function starsFromMisses(misses) {
	if (misses <= 0) return 3;
	if (misses <= 2) return 2;
	if (misses <= 5) return 1;
	return 0;
}
//#endregion
export { emptyProfile as a, roundCount as c, authMiddleware as i, starsFromMisses as l, CASE_IDS as n, levelLabel as o, LEVELS as r, rankForXp as s, CASES as t, xpFor as u };
