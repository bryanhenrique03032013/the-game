//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cxq3s-DK.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/diploma",
			"/login",
			"/caso/$slug",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-DqPXd0An.js",
			"/assets/react-SIfiwpqq.js",
			"/assets/preload-helper-fo4ijfIP.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DqPXd0An.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Dghlo7TW.js", "/assets/hub-CPU-vFQy.js"]
	},
	"/diploma": {
		filePath: "/workspace/src/routes/diploma.tsx",
		children: void 0,
		preloads: ["/assets/diploma-D4KFLAew.js", "/assets/hub-CPU-vFQy.js"]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-CQgUrswE.js",
			"/assets/hub-CPU-vFQy.js",
			"/assets/client-C85fcJ4s.js"
		]
	},
	"/caso/$slug": {
		filePath: "/workspace/src/routes/caso.$slug.tsx",
		children: void 0,
		preloads: ["/assets/caso._slug-PwG2tsrc.js", "/assets/hub-CPU-vFQy.js"]
	}
} });
//#endregion
export { tsrStartManifest };
