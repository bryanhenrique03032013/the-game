import { useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Newspaper } from "lucide-react";
import { BRYAN } from "@/lib/game/questions";
import { pickByLevel, pickFresh, shuffle } from "@/lib/game/shuffle";
import { CASES, roundCount, starsFromMisses, xpFor } from "@/lib/game/types";
import { sfx } from "@/lib/game/sfx";
import { useGame } from "@/store/game";
import { Btn, StampFlash } from "./chrome";
import { CaseFrame } from "./case-frame";
import { cn } from "@/lib/utils";

const META = CASES[1]!;

export function CaseBryan() {
  const navigate = useNavigate();
  const { profile, finishCase } = useGame();
  const items = useMemo(() => {
    const n = roundCount(profile.level, "bryan");
    return pickFresh(pickByLevel(BRYAN, profile.level), n);
  }, [profile.level]);
  const [i, setI] = useState(0);
  const [misses, setMisses] = useState(0);
  const [choice, setChoice] = useState<"real" | "fake" | null>(null);
  const [stamp, setStamp] = useState(false);
  const [saving, setSaving] = useState(false);
  const item = items[i]!;
  const order = useMemo(
    () => shuffle(["fake", "real"] as const, i * 97 + item.id.length),
    [i, item.id],
  );
  const last = i >= items.length - 1 && choice === "fake";

  function pick(kind: "real" | "fake") {
    if (choice) return;
    if (kind === "fake") {
      sfx.stamp();
      setChoice("fake");
      setStamp(true);
      window.setTimeout(() => setStamp(false), 700);
    } else {
      sfx.bad();
      setMisses((m) => m + 1);
      setChoice("real");
    }
  }

  async function next() {
    if (choice !== "fake") {
      setChoice(null);
      return;
    }
    if (!last) {
      setI((n) => n + 1);
      setChoice(null);
      return;
    }
    setSaving(true);
    const stars = starsFromMisses(misses);
    const first = !profile.cases.bryan.completed;
    await finishCase({
      caseId: "bryan",
      completed: true,
      stars,
      score: Math.max(0, 100 - misses * 12),
      clue: item.clue,
      xpGain: xpFor(profile.level, first, stars),
    });
    sfx.win();
    navigate({ to: "/" });
  }

  return (
    <CaseFrame meta={META} step={i + (choice === "fake" ? 1 : 0)} total={items.length}>
      <StampFlash text="FAKE" show={stamp} />
      <div className="mb-4 flex items-center gap-2 text-sm text-ink/60">
        <Newspaper className="size-4 text-stamp" />
        Duas notas. Uma tem fonte. A outra é boato. Carimbe a FAKE.
      </div>
      <p className="mb-3 font-display text-xl">Dossiê: {item.topic}</p>
      <div className="grid gap-3 md:grid-cols-2">
        {order.map((kind) => {
          const fake = kind === "fake";
          const selected = choice === kind;
          return (
            <button
              key={kind}
              type="button"
              onClick={() => pick(kind)}
              className={cn(
                "rounded-2xl border p-4 text-left transition",
                selected && fake && "border-stamp bg-stamp/10",
                selected && !fake && "border-ink/20 bg-ink/5",
                !selected && "border-ink/10 bg-paper-2/50 hover:border-ink/30",
              )}
            >
              <p className="font-display text-lg leading-snug">
                {fake ? item.fakeHeadline : item.realHeadline}
              </p>
              <p className="mt-2 text-sm leading-relaxed text-ink/75">
                {fake ? item.fakeBody : item.realBody}
              </p>
              {!fake ? (
                <p className="mt-3 text-xs uppercase tracking-[0.14em] text-ink/45">
                  Fonte: {item.realSource}
                </p>
              ) : (
                <p className="mt-3 text-xs uppercase tracking-[0.14em] text-stamp/80">
                  Sem fonte verificável
                </p>
              )}
            </button>
          );
        })}
      </div>
      {choice === "fake" ? (
        <div className="mt-5 space-y-3 rounded-2xl border border-ink/10 bg-folder/40 p-4">
          <p className="font-display text-lg">Carimbo aplicado</p>
          <p className="text-sm text-ink/80">{item.tell}</p>
          <Btn onClick={next} variant="stamp" className="w-full" disabled={saving}>
            {last ? (saving ? "Arquivando…" : "Arquivar pista e voltar") : "Próximo par"}
          </Btn>
        </div>
      ) : choice === "real" ? (
        <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center">
          <p className="text-sm text-stamp">Essa tem fonte. A fake é a outra.</p>
          <Btn onClick={() => setChoice(null)} variant="ink" className="sm:ml-auto">
            Tentar de novo
          </Btn>
        </div>
      ) : null}
    </CaseFrame>
  );
}
