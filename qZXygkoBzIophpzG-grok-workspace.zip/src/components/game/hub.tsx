import { useEffect, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { Lock, Search, Shield } from "lucide-react";
import {
  CASES,
  LEVELS,
  levelLabel,
  rankForXp,
} from "@/lib/game/types";
import { sfx, unlockAudio } from "@/lib/game/sfx";
import { useGame } from "@/store/game";
import { Btn, Field, Input, PaperCard, StationShell, Tape, TopBar } from "./chrome";
import { cn } from "@/lib/utils";

export function HubScreen() {
  const navigate = useNavigate();
  const { profile, setLevel, setBadge, markBriefing } = useGame();
  const [name, setName] = useState(profile.badgeName);
  const [savingName, setSavingName] = useState(false);
  const lockedFinal = !CASES[4]!.lockedUntil?.every((id) => profile.cases[id].completed);

  useEffect(() => {
    setName(profile.badgeName);
  }, [profile.badgeName]);

  async function saveName() {
    setSavingName(true);
    await setBadge(name);
    setSavingName(false);
  }

  return (
    <StationShell>
      <TopBar profile={profile} />
      <div className="relative overflow-hidden rounded-[32px] border border-paper/10 bg-ink-2 px-5 py-6 sm:px-8">
        <Tape className="absolute -left-6 top-5 h-6 rotate-[-3deg] opacity-90" />
        <Tape className="absolute -right-10 bottom-6 h-5 rotate-[4deg] opacity-70" />
        <p className="relative font-display text-xs tracking-[0.28em] text-tape">CENA DO CRIME</p>
        <h1 className="relative mt-3 max-w-xl font-display text-3xl leading-tight sm:text-4xl">
          Quatro salas. Um gabinete. A língua portuguesa sob investigação.
        </h1>
        <p className="relative mt-3 max-w-lg text-sm text-paper/70">
          {rankForXp(profile.xp)} {profile.badgeName}, nível {levelLabel(profile.level)}.
          Prenda os erros, colete as pistas e peça o carimbo da chefe Manuella.
        </p>
      </div>

      <div className="mt-5 grid gap-3 sm:grid-cols-3">
        <PaperCard className="sm:col-span-2">
          <p className="text-xs uppercase tracking-[0.16em] text-ink/50">Seleção de nível</p>
          <div className="mt-3 grid grid-cols-3 gap-2">
            {LEVELS.map((level) => (
              <button
                key={level}
                type="button"
                onClick={() => {
                  unlockAudio();
                  sfx.tick();
                  void setLevel(level);
                }}
                className={cn(
                  "min-h-11 rounded-xl border px-2 py-3 font-display text-sm",
                  profile.level === level
                    ? "border-stamp bg-stamp text-paper"
                    : "border-ink/15 bg-paper-2 text-ink hover:border-ink/40",
                )}
              >
                {levelLabel(level)}
              </button>
            ))}
          </div>
          <p className="mt-3 text-xs text-ink/55">
            Iniciante: 5 frases. Intermediário: 7. Avançado: 10 no mural da Anne, com Enem no gabinete.
            As perguntas mudam a cada entrada na sala.
          </p>
        </PaperCard>
        <PaperCard>
          <Field label="Nome no crachá">
            <Input value={name} maxLength={32} onChange={(e) => setName(e.target.value)} />
          </Field>
          <Btn className="mt-3 w-full" variant="ink" disabled={savingName} onClick={saveName}>
            {savingName ? "Gravando…" : "Atualizar crachá"}
          </Btn>
        </PaperCard>
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        {CASES.map((meta) => {
          const progress = profile.cases[meta.id];
          const locked = meta.id === "manuella" && lockedFinal;
          const cardClass = cn(
            "block rounded-[28px] border p-5 transition",
            locked
              ? "cursor-not-allowed border-tape/40 bg-ink-2/80 text-paper/70"
              : progress.completed
                ? "border-paper/20 bg-ink-3 text-paper hover:border-paper/40"
                : "border-paper/15 bg-ink-2 text-paper hover:border-tape/50",
          );
          const body = (
            <>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-[10px] uppercase tracking-[0.18em] text-tape">{meta.desk}</p>
                  <h2 className="mt-1 font-display text-2xl">{meta.detective}</h2>
                  <p className="text-sm text-paper/70">{meta.title}</p>
                </div>
                {locked ? (
                  <Lock className="size-5 text-tape" />
                ) : progress.completed ? (
                  <Shield className="size-5 text-paper" />
                ) : (
                  <Search className="size-5 text-tape" />
                )}
              </div>
              <p className="mt-3 text-sm text-paper/65">{meta.crime}</p>
              <div className="mt-4 flex items-center justify-between text-xs uppercase tracking-[0.14em]">
                <span>{locked ? "Traga 4 pistas" : progress.completed ? "Pista arquivada" : "Abrir sala"}</span>
                {progress.completed ? <span className="text-tape">{progress.stars}/3</span> : null}
              </div>
            </>
          );
          if (locked) {
            return (
              <div key={meta.id} className={cardClass}>
                {body}
              </div>
            );
          }
          return (
            <Link
              key={meta.id}
              to="/caso/$slug"
              params={{ slug: meta.id }}
              onClick={() => unlockAudio()}
              className={cardClass}
            >
              {body}
            </Link>
          );
        })}
      </div>

      {profile.certified ? (
        <div className="mt-5">
          <Btn variant="paper" className="w-full" onClick={() => navigate({ to: "/diploma" })}>
            Ver certificado Nota 1000
          </Btn>
        </div>
      ) : null}

      {!profile.seenBriefing ? (
        <Briefing onDone={() => void markBriefing()} />
      ) : null}
    </StationShell>
  );
}

function Briefing({ onDone }: { onDone: () => void }) {
  return (
    <div className="fixed inset-0 z-40 grid place-items-end bg-ink/70 p-4 sm:place-items-center">
      <PaperCard className="w-full max-w-lg rotate-[-0.6deg]">
        <p className="text-xs uppercase tracking-[0.2em] text-stamp">Chefe Manuella</p>
        <h2 className="mt-2 font-display text-2xl">Plantão da língua</h2>
        <p className="mt-3 text-sm leading-relaxed text-ink/80">
          Recruta, a delegacia está lotada de frases foragidas. Anne cuida da concordância. Bryan
          caça fake news. Bedin vasculha o quadro-negro. Lívia reconstitui a pontuação. Quando as
          quatro pistas estiverem na mesa, você monta o parágrafo do Enem — com conectivos — e
          leva o certificado de Policial da Língua Portuguesa Nota 1000.
        </p>
        <Btn className="mt-5 w-full" variant="stamp" onClick={onDone}>
          Assinar o crachá e entrar
        </Btn>
      </PaperCard>
    </div>
  );
}

export function TitleScreen({ onEnter }: { onEnter: () => void }) {
  return (
    <StationShell>
      <div className="flex min-h-[calc(100dvh-4rem)] flex-col justify-center">
        <div className="overflow-hidden">
          <Tape className="mb-8 h-7 -rotate-2" />
        </div>
        <p className="font-display text-sm tracking-[0.4em] text-tape">ERRO GRAMATICAL · CENA DO CRIME</p>
        <h1 className="mt-4 font-display text-5xl leading-[0.95] sm:text-7xl">D.L.P.</h1>
        <p className="mt-2 font-display text-2xl text-paper/85 sm:text-3xl">Delegacia da Língua</p>
        <p className="mt-4 max-w-md text-sm text-paper/70">
          RPG de plantão: crachá de detetive, fita zebrada, lupas de papelão e frases foragidas.
          Salve o progresso na sua conta e escolha o nível antes de abrir as salas.
        </p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <Btn variant="paper" className="sm:min-w-48" onClick={onEnter}>
            Apresentar-se
          </Btn>
          <a
            href="/login"
            className="inline-flex min-h-11 items-center justify-center rounded-xl border border-paper/40 bg-ink-3 px-4 text-sm text-paper"
          >
            Já tenho crachá
          </a>
        </div>
        <div className="mt-10 flex flex-wrap gap-3">
          {[
            ["Anne", "Concordância"],
            ["Bryan", "Fake news"],
            ["Bedin", "Ortografia"],
            ["Lívia", "Pontuação"],
            ["Manuella", "Caso final"],
          ].map(([who, job]) => (
            <div key={who} className="min-w-[9.5rem] flex-1 rounded-2xl border border-paper/10 bg-ink-2 px-4 py-3">
              <p className="font-display text-lg">{who}</p>
              <p className="text-xs uppercase tracking-[0.14em] text-paper/50">{job}</p>
            </div>
          ))}
        </div>
        <div className="overflow-hidden">
          <Tape className="mt-10 h-6 rotate-2" />
        </div>
      </div>
    </StationShell>
  );
}

export function LoadingDossier() {
  return (
    <StationShell>
      <div className="grid min-h-[70dvh] place-items-center">
        <div className="w-full max-w-sm rounded-[28px] border border-paper/10 bg-ink-2 p-6">
          <p className="font-display text-xs tracking-[0.24em] text-tape">D.L.P.</p>
          <h1 className="mt-2 font-display text-2xl">Abrindo o dossiê</h1>
          <p className="mt-2 text-sm text-paper/60">A recepção está conferindo o crachá.</p>
          <div className="mt-6 h-24 animate-pulse rounded-2xl bg-paper/10" />
        </div>
      </div>
    </StationShell>
  );
}
