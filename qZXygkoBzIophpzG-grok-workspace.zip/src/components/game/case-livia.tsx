import { useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { PenLine } from "lucide-react";
import { LIVIA } from "@/lib/game/questions";
import { pickByLevel, pickFresh } from "@/lib/game/shuffle";
import { CASES, roundCount, starsFromMisses, xpFor } from "@/lib/game/types";
import { sfx } from "@/lib/game/sfx";
import { useGame } from "@/store/game";
import { Btn, StampFlash } from "./chrome";
import { CaseFrame } from "./case-frame";
import { cn } from "@/lib/utils";

const META = CASES[3]!;

export function CaseLivia() {
  const navigate = useNavigate();
  const { profile, finishCase } = useGame();
  const items = useMemo(() => {
    const n = roundCount(profile.level, "livia");
    return pickFresh(pickByLevel(LIVIA, profile.level), n);
  }, [profile.level]);
  const [i, setI] = useState(0);
  const [misses, setMisses] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [stamp, setStamp] = useState(false);
  const [saving, setSaving] = useState(false);
  const item = items[i]!;
  const locked = picked === item.correct;
  const last = i >= items.length - 1 && locked;

  function choose(index: number) {
    if (locked) return;
    if (index === item.correct) {
      sfx.stamp();
      setPicked(index);
      setStamp(true);
      window.setTimeout(() => setStamp(false), 650);
    } else {
      sfx.bad();
      setMisses((m) => m + 1);
      setPicked(index);
    }
  }

  async function next() {
    if (!locked) {
      setPicked(null);
      return;
    }
    if (!last) {
      setI((n) => n + 1);
      setPicked(null);
      return;
    }
    setSaving(true);
    const stars = starsFromMisses(misses);
    const first = !profile.cases.livia.completed;
    await finishCase({
      caseId: "livia",
      completed: true,
      stars,
      score: Math.max(0, 100 - misses * 8),
      clue: item.clue,
      xpGain: xpFor(profile.level, first, stars),
    });
    sfx.win();
    navigate({ to: "/" });
  }

  return (
    <CaseFrame meta={META} step={i + (locked ? 1 : 0)} total={items.length}>
      <StampFlash text="CORRIGIDO" show={stamp} />
      <div className="mb-4 flex items-center gap-2 text-sm text-ink/60">
        <PenLine className="size-4 text-stamp" />
        Escolha a versão com pontuação e crase no lugar certo.
      </div>
      <p className="mb-4 rounded-2xl bg-ink px-4 py-3 font-display text-lg text-paper">
        {item.prompt}
      </p>
      <div className="space-y-2">
        {item.options.map((option, index) => {
          const selected = picked === index;
          const good = locked && index === item.correct;
          const bad = selected && index !== item.correct;
          return (
            <button
              key={option}
              type="button"
              onClick={() => choose(index)}
              className={cn(
                "w-full rounded-2xl border px-4 py-3 text-left text-sm leading-relaxed sm:text-base",
                good && "border-ok bg-ok/10",
                bad && "border-stamp bg-stamp/10",
                !selected && "border-ink/10 bg-paper-2/60 hover:border-ink/30",
              )}
            >
              {option}
            </button>
          );
        })}
      </div>
      {locked ? (
        <div className="mt-5 space-y-3 rounded-2xl border border-ink/10 bg-folder/40 p-4">
          <p className="text-sm text-ink/80">{item.why}</p>
          <Btn onClick={next} variant="stamp" className="w-full" disabled={saving}>
            {last ? (saving ? "Arquivando…" : "Arquivar pista e voltar") : "Próxima folha"}
          </Btn>
        </div>
      ) : picked !== null && picked !== item.correct ? (
        <p className="mt-4 text-sm text-stamp">Ainda falta uma vírgula ou uma crase nessa pista.</p>
      ) : null}
    </CaseFrame>
  );
}
