import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { PaperCard, ProgressDots, StationShell, Tape, TopBar } from "./chrome";
import { useGame } from "@/store/game";
import type { CaseMeta } from "@/lib/game/types";

export function CaseFrame({
  meta,
  step,
  total,
  children,
  footer,
}: {
  meta: CaseMeta;
  step: number;
  total: number;
  children: ReactNode;
  footer?: ReactNode;
}) {
  const profile = useGame((s) => s.profile);
  return (
    <StationShell>
      <TopBar profile={profile} />
      <div className="relative mb-5">
        <Tape className="absolute -left-8 top-2 h-6 rotate-[-2deg]" />
        <p className="relative pt-8 font-display text-xs tracking-[0.22em] text-tape">
          CENA DO CRIME · ERRO GRAMATICAL
        </p>
      </div>
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-[0.18em] text-paper/50">{meta.desk}</p>
          <h1 className="font-display text-2xl text-paper sm:text-3xl">{meta.detective}</h1>
          <p className="text-sm text-paper/70">{meta.title}</p>
        </div>
        <Link
          to="/"
          className="inline-flex min-h-11 items-center gap-1 rounded-xl border border-paper/20 px-3 text-sm text-paper/80"
        >
          <ArrowLeft className="size-4" />
          Delegacia
        </Link>
      </div>
      <PaperCard>
        <p className="mb-3 text-xs font-medium uppercase tracking-[0.16em] text-stamp">
          Crime: {meta.crime}
        </p>
        <ProgressDots current={step} total={total} />
        <div className="mt-5">{children}</div>
        {footer ? <div className="mt-5 border-t border-ink/10 pt-4">{footer}</div> : null}
      </PaperCard>
    </StationShell>
  );
}
