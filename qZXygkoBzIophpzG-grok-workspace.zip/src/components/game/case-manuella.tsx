import { useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Stamp } from "lucide-react";
import { FINALS } from "@/lib/game/questions";
import { pickFresh } from "@/lib/game/shuffle";
import { CASES, xpFor } from "@/lib/game/types";
import { sfx } from "@/lib/game/sfx";
import { useGame } from "@/store/game";
import { Btn, PaperCard, StampFlash, StationShell, Tape, TopBar } from "./chrome";
import { cn } from "@/lib/utils";

const META = CASES[4]!;

export function CaseManuella() {
  const navigate = useNavigate();
  const { profile, finishCase, certify } = useGame();
  const ready = META.lockedUntil?.every((id) => profile.cases[id].completed) ?? false;
  const item = useMemo(() => pickFresh(FINALS, 1)[0]!, []);
  const clues = [
    profile.cases.anne.clue || item.parts[0],
    profile.cases.bryan.clue || item.parts[1],
    profile.cases.bedin.clue || item.parts[2],
    profile.cases.livia.clue || item.parts[3],
  ];
  const [picks, setPicks] = useState<(string | null)[]>([null, null, null]);
  const [misses, setMisses] = useState(0);
  const [checked, setChecked] = useState(false);
  const [stamp, setStamp] = useState(false);
  const [saving, setSaving] = useState(false);
  const ok = picks.every((p, i) => p === item.slots[i]?.correct);

  function choose(slot: number, value: string) {
    setChecked(false);
    setPicks((prev) => {
      const next = [...prev];
      next[slot] = value;
      return next;
    });
  }

  function verify() {
    if (picks.some((p) => !p)) return;
    if (ok) {
      sfx.stamp();
      setChecked(true);
      setStamp(true);
      window.setTimeout(() => setStamp(false), 800);
    } else {
      sfx.bad();
      setMisses((m) => m + 1);
      setChecked(true);
    }
  }

  async function closeCase() {
    setSaving(true);
    const stars = misses === 0 ? 3 : misses < 3 ? 2 : 1;
    const first = !profile.cases.manuella.completed;
    const score = Math.max(40, 100 - misses * 10);
    await finishCase({
      caseId: "manuella",
      completed: true,
      stars,
      score,
      clue: "Parágrafo reconstruído com conectivos.",
      xpGain: xpFor(profile.level, first, stars) + 40,
    });
    await certify(score);
    sfx.win();
    navigate({ to: "/diploma" });
  }

  const paragraph = [
    clues[0],
    picks[0] ? `, ${picks[0]!.toLowerCase()}` : " ___",
    ` ${clues[1]}`,
    picks[1] ? `; ${picks[1]}` : " ___",
    ` ${clues[2]}. `,
    picks[2] ?? "___",
    `, ${clues[3]} ${item.closing}`,
  ].join("");

  if (!ready) {
    return (
      <StationShell>
        <TopBar profile={profile} />
        <PaperCard>
          <Tape className="mb-4 h-6 rotate-[-2deg]" />
          <h1 className="font-display text-2xl">Gabinete lacrado</h1>
          <p className="mt-2 text-sm text-ink/70">
            A chefe Manuella só recebe quem trouxer as quatro pistas das salas 1 a 4.
          </p>
          <Btn className="mt-5" variant="ink" onClick={() => navigate({ to: "/" })}>
            Voltar à delegacia
          </Btn>
        </PaperCard>
      </StationShell>
    );
  }

  return (
    <StationShell>
      <TopBar profile={profile} />
      <StampFlash text="APROVADO" show={stamp} />
      <p className="font-display text-xs tracking-[0.22em] text-tape">GABINETE DA CHEFE</p>
      <h1 className="mt-1 font-display text-3xl">{item.title}</h1>
      <p className="mt-1 text-sm text-paper/70">{META.desk}</p>
      <PaperCard className="mt-5">
        <div className="mb-3 flex items-center gap-2 text-sm text-ink/60">
          <Stamp className="size-4 text-stamp" />
          {item.brief}
        </div>
        <div className="mb-4 grid gap-2 sm:grid-cols-2">
          {clues.map((clue, index) => (
            <div key={clue} className="rounded-2xl border border-dashed border-ink/20 bg-folder/30 p-3">
              <p className="text-[10px] uppercase tracking-[0.16em] text-ink/45">Pista {index + 1}</p>
              <p className="font-display text-sm">{clue}</p>
            </div>
          ))}
        </div>
        <p className="rounded-2xl bg-ink px-4 py-3 text-sm leading-relaxed text-paper">{paragraph}</p>
        <div className="mt-5 space-y-4">
          {item.slots.map((slot, index) => (
            <div key={slot.correct}>
              <p className="mb-2 text-xs uppercase tracking-[0.16em] text-ink/50">
                Conectivo {index + 1}
              </p>
              <div className="flex flex-wrap gap-2">
                {slot.options.map((option) => (
                  <button
                    key={option}
                    type="button"
                    onClick={() => choose(index, option)}
                    className={cn(
                      "min-h-11 rounded-xl border px-3 py-2 text-sm",
                      picks[index] === option
                        ? "border-stamp bg-stamp text-paper"
                        : "border-ink/15 bg-paper-2 hover:border-ink/40",
                    )}
                  >
                    {option}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
        {checked && !ok ? (
          <p className="mt-4 text-sm text-stamp">
            A banca ainda não aceita essa coesão. Troque um conectivo e tente de novo.
          </p>
        ) : null}
        <div className="mt-5 flex flex-col gap-2 sm:flex-row">
          {!ok || !checked ? (
            <Btn variant="stamp" className="flex-1" onClick={verify} disabled={picks.some((p) => !p)}>
              Submeter à banca
            </Btn>
          ) : (
            <Btn variant="stamp" className="flex-1" onClick={closeCase} disabled={saving}>
              {saving ? "Carimbando…" : "Receber certificado Nota 1000"}
            </Btn>
          )}
          <Btn variant="ghost" className="text-ink sm:w-auto" onClick={() => navigate({ to: "/" })}>
            Voltar
          </Btn>
        </div>
      </PaperCard>
    </StationShell>
  );
}
