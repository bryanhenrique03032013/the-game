import type { InputHTMLAttributes, ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { UserButton } from "@/lib/auth/gates";
import { cn } from "@/lib/utils";
import { levelLabel, rankForXp, type Profile } from "@/lib/game/types";

export function Tape({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        "crime-tape h-7 w-[140%] max-w-none shadow-[0_8px_16px_rgba(0,0,0,0.35)]",
        className,
      )}
      aria-hidden="true"
    />
  );
}

export function StationShell({ children }: { children: ReactNode }) {
  return (
    <div className="station-bg relative min-h-dvh overflow-x-hidden text-paper">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-24 bg-[linear-gradient(180deg,rgba(0,0,0,0.45),transparent)]" />
      <div className="relative mx-auto w-full max-w-5xl px-4 pb-16 pt-[max(1rem,env(safe-area-inset-top))] sm:px-6">
        {children}
      </div>
    </div>
  );
}

export function TopBar({ profile }: { profile: Profile }) {
  return (
    <header className="mb-6 flex items-start justify-between gap-3">
      <Link to="/" className="min-w-0">
        <p className="font-display text-xs tracking-[0.28em] text-tape">D.L.P.</p>
        <p className="truncate font-display text-lg text-paper">Delegacia da Língua</p>
      </Link>
      <div className="flex shrink-0 items-center gap-3 rounded-[28px] border border-paper/15 bg-ink-2/80 px-3 py-2">
        <div className="hidden text-right sm:block">
          <p className="font-display text-sm leading-tight">{profile.badgeName}</p>
          <p className="text-xs text-paper/60">
            {rankForXp(profile.xp)} · {levelLabel(profile.level)} · {profile.xp} XP
          </p>
        </div>
        <div className="text-paper [&_button]:text-paper/70 [&_span]:text-paper">
          <UserButton />
        </div>
      </div>
    </header>
  );
}

export function PaperCard({
  children,
  className,
  rotate,
}: {
  children: ReactNode;
  className?: string;
  rotate?: boolean;
}) {
  return (
    <div
      className={cn(
        "paper-grain paper-enter text-ink rounded-[28px] p-4 shadow-[0_18px_40px_rgba(0,0,0,0.35)] sm:p-6",
        rotate && "rotate-[-0.4deg]",
        className,
      )}
    >
      {children}
    </div>
  );
}

export function Btn({
  children,
  onClick,
  type = "button",
  variant = "paper",
  className,
  disabled,
}: {
  children: ReactNode;
  onClick?: () => void;
  type?: "button" | "submit";
  variant?: "paper" | "stamp" | "ghost" | "ink";
  className?: string;
  disabled?: boolean;
}) {
  const styles = {
    paper:
      "bg-paper text-ink hover:bg-paper-2",
    stamp:
      "bg-stamp text-paper hover:bg-stamp-2",
    ghost:
      "bg-transparent text-paper border border-paper/25 hover:bg-paper/10",
    ink: "bg-ink text-paper hover:bg-ink-3 border border-ink-3",
  }[variant];
  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "inline-flex min-h-11 items-center justify-center rounded-xl px-4 py-2.5 text-center font-medium transition-transform duration-[150ms] ease-[cubic-bezier(0.22,1,0.36,1)] active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50",
        styles,
        className,
      )}
    >
      {children}
    </button>
  );
}

export function StampFlash({ text, show }: { text: string; show: boolean }) {
  if (!show) return null;
  return (
    <div className="pointer-events-none fixed inset-0 z-50 grid place-items-center">
      <div className="stamp-pop wanted-stamp rounded-md px-7 py-4 text-4xl">{text}</div>
    </div>
  );
}

export function StarsRow({ n }: { n: number }) {
  return (
    <span className="font-display tracking-[0.3em] text-stamp" aria-label={`${n} estrelas`}>
      {"★".repeat(n)}
      <span className="text-ink/25">{"★".repeat(Math.max(0, 3 - n))}</span>
    </span>
  );
}

export function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="block space-y-1.5">
      <span className="text-xs font-medium uppercase tracking-[0.16em] text-ink/55">{label}</span>
      {children}
    </label>
  );
}

export function Input(props: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={cn(
        "h-11 w-full rounded-lg border border-ink/15 bg-paper px-3 text-ink outline-none ring-stamp/0 transition focus:border-stamp focus:ring-2 focus:ring-stamp/30",
        props.className,
      )}
    />
  );
}

export function ProgressDots({ current, total }: { current: number; total: number }) {
  return (
    <div className="flex gap-1.5" aria-label={`Pista ${current} de ${total}`}>
      {Array.from({ length: total }, (_, i) => (
        <span
          key={i}
          className={cn(
            "h-1.5 flex-1 rounded-full",
            i < current ? "bg-stamp" : "bg-ink/15",
          )}
        />
      ))}
    </div>
  );
}
