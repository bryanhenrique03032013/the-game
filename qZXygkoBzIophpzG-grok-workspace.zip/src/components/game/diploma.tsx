import { useNavigate } from "@tanstack/react-router";
import { Btn, PaperCard, StationShell, Tape, TopBar } from "./chrome";
import { useGame } from "@/store/game";
import { levelLabel } from "@/lib/game/types";

export function DiplomaScreen() {
  const navigate = useNavigate();
  const profile = useGame((s) => s.profile);
  const date = new Date().toLocaleDateString("pt-BR");

  return (
    <StationShell>
      <TopBar profile={profile} />
      <Tape className="mb-6 h-6 -rotate-1" />
      <PaperCard rotate className="mx-auto max-w-xl border-[10px] border-double border-ink/20">
        <p className="text-center text-xs uppercase tracking-[0.28em] text-stamp">
          Delegacia da Língua Portuguesa
        </p>
        <h1 className="mt-4 text-center font-display text-3xl sm:text-4xl">Certificado</h1>
        <p className="mt-2 text-center font-display text-lg text-ink/70">
          Policial da Língua Portuguesa Nota 1000
        </p>
        <div className="wanted-stamp mx-auto mt-5 w-fit px-4 py-2 text-xl">Aprovado</div>
        <p className="mt-6 text-center text-sm leading-relaxed text-ink/80">
          Confere-se a <span className="font-display text-lg text-ink">{profile.badgeName}</span> o
          título de detetive do plantão {levelLabel(profile.level)}, por reunir as pistas de Anne,
          Bryan, Bedin e Lívia e reconstruir o parágrafo com conectivos.
        </p>
        <div className="mt-6 flex justify-between border-t border-ink/15 pt-4 text-xs uppercase tracking-[0.14em] text-ink/50">
          <span>Chefe Manuella</span>
          <span>{date}</span>
          <span>{profile.certificateScore || profile.xp} pts</span>
        </div>
      </PaperCard>
      <div className="mx-auto mt-6 flex max-w-xl flex-col gap-2 sm:flex-row">
        <Btn className="flex-1" variant="paper" onClick={() => navigate({ to: "/" })}>
          Voltar à delegacia
        </Btn>
        <Btn
          className="flex-1"
          variant="ghost"
          onClick={() => navigate({ to: "/caso/$slug", params: { slug: "manuella" } })}
        >
          Reabrir o caso final
        </Btn>
      </div>
    </StationShell>
  );
}
