import { useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { ANNE } from "@/lib/game/questions";
import { pickByLevel, pickFresh } from "@/lib/game/shuffle";
import { CASES, roundCount, starsFromMisses, xpFor } from "@/lib/game/types";
import { sfx } from "@/lib/game/sfx";
import { useGame } from "@/store/game";
import { Btn, StampFlash } from "./chrome";
import { CaseFrame } from "./case-frame";
import { cn } from "@/lib/utils";

const META = CASES[0]!;

export function CaseAnne() {
  const navigate = useNavigate();
  const { profile, finishCase } = useGame();
  const items = useMemo(() => {
    const n = roundCount(profile.level, "anne");
    return pickFresh(pickByLevel(ANNE, profile.level), n);
  }, [profile.level]);
  const [i, setI] = useState(0);
  const [misses, setMisses] = useState(0);
  const [locked, setLocked] = useState(false);
  const [picked, setPicked] = useState<number | null>(null);
  const [stamp, setStamp] = useState(false);
  const [shake, setShake] = useState(false);
  const [saving, setSaving] = useState(false);
  const item = items[i]!;
  const last = i >= items.length - 1 && locked;

  function tap(index: number, bad?: boolean) {
    if (locked) return;
    setPicked(index);
    if (bad) {
      sfx.stamp();
      setLocked(true);
      setStamp(true);
      window.setTimeout(() => setStamp(false), 700);
    } else {
      sfx.bad();
      setMisses((m) => m + 1);
      setShake(true);
      window.setTimeout(() => setShake(false), 280);
    }
  }

  async function next() {
    if (!last) {
      setI((n) => n + 1);
      setLocked(false);
      setPicked(null);
      return;
    }
    setSaving(true);
    const stars = starsFromMisses(misses);
    const first = !profile.cases.anne.completed;
    await finishCase({
      caseId: "anne",
      completed: true,
      stars,
      score: Math.max(0, 100 - misses * 8),
      clue: item.clue,
      xpGain: xpFor(profile.level, first, stars),
    });
    sfx.win();
    navigate({ to: "/" });
  }

  return (
    <CaseFrame meta={META} step={i + (locked ? 1 : 0)} total={items.length}>
      <StampFlash text="PRESO" show={stamp} />
      <div className="mb-4 flex items-center gap-2 text-sm text-ink/60">
        <Search className="size-4 text-stamp" />
        Toque na palavra errada e prenda com o X vermelho.
      </div>
      <div className={cn("flex flex-wrap gap-2", shake && "shake")}>
        {item.words.map((word, index) => {
          const selected = picked === index;
          const guilty = locked && word.bad;
          return (
            <button
              key={`${word.t}-${index}`}
              type="button"
              onClick={() => tap(index, word.bad)}
              className={cn(
                "relative min-h-11 rounded-lg border px-3 py-2 text-lg transition",
                guilty
                  ? "border-stamp bg-stamp text-paper"
                  : selected && !word.bad
                    ? "border-stamp/40 bg-stamp/10"
                    : "border-ink/10 bg-paper-2/60 text-ink hover:border-ink/30",
              )}
              data-guilty={word.bad ? "1" : undefined}
            >
              {word.t}
              {guilty ? (
                <span className="absolute -right-1 -top-2 font-display text-2xl text-paper">X</span>
              ) : null}
            </button>
          );
        })}
      </div>
      {locked ? (
        <div className="mt-5 space-y-3 rounded-2xl border border-ink/10 bg-folder/40 p-4">
          <p className="font-display text-lg">Mandado cumprido</p>
          <p className="text-sm leading-relaxed text-ink/80">{item.why}</p>
          <p className="rounded-lg bg-paper px-3 py-2 font-display text-base">{item.fix}</p>
          <Btn onClick={next} variant="stamp" className="w-full" disabled={saving}>
            {last ? (saving ? "Arquivando…" : "Arquivar pista e voltar") : "Próxima frase"}
          </Btn>
        </div>
      ) : picked !== null && !item.words[picked]?.bad ? (
        <p className="mt-4 text-sm text-stamp">Essa palavra é inocente. Continue vasculhando.</p>
      ) : null}
    </CaseFrame>
  );
}
