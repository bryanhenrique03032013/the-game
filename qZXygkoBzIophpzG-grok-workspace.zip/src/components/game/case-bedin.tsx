import { useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Grid3x3 } from "lucide-react";
import { BEDIN } from "@/lib/game/questions";
import { pickByLevel, pickFresh, freshSeed } from "@/lib/game/shuffle";
import { buildWordSearch, cellsEqual, lineBetween, type GridCell } from "@/lib/game/wordsearch";
import { CASES, roundCount, starsFromMisses, xpFor } from "@/lib/game/types";
import { sfx } from "@/lib/game/sfx";
import { useGame } from "@/store/game";
import { Btn, StampFlash } from "./chrome";
import { CaseFrame } from "./case-frame";
import { cn } from "@/lib/utils";

const META = CASES[2]!;

export function CaseBedin() {
  const navigate = useNavigate();
  const { profile, finishCase } = useGame();
  const seed = useMemo(() => freshSeed(), []);
  const words = useMemo(() => {
    const n = roundCount(profile.level, "bedin");
    return pickFresh(pickByLevel(BEDIN, profile.level), n, [], seed);
  }, [profile.level, seed]);
  const size = profile.level === "avancado" ? 10 : profile.level === "intermediario" ? 9 : 8;
  const puzzle = useMemo(() => buildWordSearch(words, size, seed), [words, size, seed]);
  const byId = useMemo(() => new Map(words.map((w) => [w.id, w])), [words]);
  const [start, setStart] = useState<GridCell | null>(null);
  const [found, setFound] = useState<string[]>([]);
  const [misses, setMisses] = useState(0);
  const [lastWhy, setLastWhy] = useState<string | null>(null);
  const [stamp, setStamp] = useState(false);
  const [saving, setSaving] = useState(false);
  const done = found.length >= puzzle.placed.length && puzzle.placed.length > 0;

  function tap(cell: GridCell) {
    if (done) return;
    if (!start) {
      setStart(cell);
      sfx.tick();
      return;
    }
    if (start.r === cell.r && start.c === cell.c) {
      setStart(null);
      return;
    }
    const line = lineBetween(start, cell);
    setStart(null);
    if (!line) {
      sfx.bad();
      setMisses((m) => m + 1);
      return;
    }
    const hit = puzzle.placed.find((p) => !found.includes(p.id) && cellsEqual(p.cells, line));
    if (!hit) {
      sfx.bad();
      setMisses((m) => m + 1);
      return;
    }
    sfx.ok();
    setFound((list) => [...list, hit.id]);
    setLastWhy(byId.get(hit.id)?.why ?? "Palavra presa.");
    setStamp(true);
    window.setTimeout(() => setStamp(false), 600);
  }

  async function archive() {
    setSaving(true);
    const stars = starsFromMisses(misses);
    const first = !profile.cases.bedin.completed;
    const clue = byId.get(found[found.length - 1] ?? "")?.clue ?? words[0]?.clue ?? "";
    await finishCase({
      caseId: "bedin",
      completed: true,
      stars,
      score: Math.max(0, 100 - misses * 7),
      clue,
      xpGain: xpFor(profile.level, first, stars),
    });
    sfx.win();
    navigate({ to: "/" });
  }

  const foundSet = new Set(
    puzzle.placed.filter((p) => found.includes(p.id)).flatMap((p) => p.cells.map((c) => `${c.r}:${c.c}`)),
  );

  return (
    <CaseFrame meta={META} step={found.length} total={Math.max(puzzle.placed.length, 1)}>
      <StampFlash text="PRESO" show={stamp} />
      <div className="mb-3 flex items-center gap-2 text-sm text-ink/60">
        <Grid3x3 className="size-4 text-stamp" />
        Toque a primeira e a última letra do erro. Palavras na horizontal, vertical ou diagonal.
      </div>
      <p className="mb-3 text-xs uppercase tracking-[0.14em] text-ink/45">
        Procurados: {puzzle.placed.map((p) => p.word).join(" · ")}
      </p>
      <div className="overflow-x-auto pb-2">
        <div
          className="mx-auto grid w-max gap-1"
          style={{ gridTemplateColumns: `repeat(${size}, minmax(2rem, 2.4rem))` }}
        >
          {puzzle.grid.map((row, r) =>
            row.map((ch, c) => {
              const key = `${r}:${c}`;
              const active = start?.r === r && start?.c === c;
              const marked = foundSet.has(key);
              const owner = puzzle.placed.find((p) =>
                p.cells.some((cell) => cell.r === r && cell.c === c),
              );
              const isStart = owner && owner.cells[0]?.r === r && owner.cells[0]?.c === c;
              const isEnd =
                owner &&
                owner.cells[owner.cells.length - 1]?.r === r &&
                owner.cells[owner.cells.length - 1]?.c === c;
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => tap({ r, c })}
                  data-word-start={isStart ? owner.id : undefined}
                  data-word-end={isEnd ? owner.id : undefined}
                  className={cn(
                    "flex size-10 items-center justify-center rounded-md font-display text-base sm:size-11",
                    marked
                      ? "bg-stamp text-paper"
                      : active
                        ? "bg-ink text-paper"
                        : "bg-paper-2 text-ink hover:bg-folder",
                  )}
                >
                  {ch}
                </button>
              );
            }),
          )}
        </div>
      </div>
      {lastWhy ? <p className="mt-4 text-sm text-ink/80">{lastWhy}</p> : null}
      {done ? (
        <div className="mt-5 space-y-3">
          <p className="font-display text-lg">Quadro limpo. Adesivo de Detetive Júnior liberado.</p>
          <Btn onClick={archive} variant="stamp" className="w-full" disabled={saving}>
            {saving ? "Arquivando…" : "Arquivar pista e voltar"}
          </Btn>
        </div>
      ) : (
        <p className="mt-3 text-xs text-ink/50">
          {found.length}/{puzzle.placed.length} erros presos
        </p>
      )}
    </CaseFrame>
  );
}
