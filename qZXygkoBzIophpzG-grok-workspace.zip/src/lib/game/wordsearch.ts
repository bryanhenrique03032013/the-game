import { mulberry32 } from "./shuffle";
import { BEDIN_FILLERS, type BedinWord } from "./questions";

export type GridCell = { r: number; c: number };
export type PlacedWord = {
  id: string;
  word: string;
  cells: GridCell[];
};

export type WordSearchPuzzle = {
  size: number;
  grid: string[][];
  placed: PlacedWord[];
};

const DIRS = [
  { dr: 0, dc: 1 },
  { dr: 1, dc: 0 },
  { dr: 1, dc: 1 },
  { dr: 0, dc: -1 },
  { dr: 1, dc: -1 },
];

export function buildWordSearch(words: BedinWord[], size: number, seed: number): WordSearchPuzzle {
  const rng = mulberry32(seed);
  const grid: string[][] = Array.from({ length: size }, () => Array.from({ length: size }, () => ""));
  const placed: PlacedWord[] = [];
  const sorted = [...words].sort((a, b) => b.wrong.length - a.wrong.length);

  for (const item of sorted) {
    const letters = item.wrong.replace(/\s/g, "").toUpperCase().split("");
    if (letters.length < 2 || letters.length > size) continue;
    let done = false;
    for (let attempt = 0; attempt < 80 && !done; attempt++) {
      const dir = DIRS[Math.floor(rng() * DIRS.length)]!;
      const r = Math.floor(rng() * size);
      const c = Math.floor(rng() * size);
      const endR = r + dir.dr * (letters.length - 1);
      const endC = c + dir.dc * (letters.length - 1);
      if (endR < 0 || endC < 0 || endR >= size || endC >= size) continue;
      const cells: GridCell[] = [];
      let ok = true;
      for (let i = 0; i < letters.length; i++) {
        const rr = r + dir.dr * i;
        const cc = c + dir.dc * i;
        const existing = grid[rr]![cc]!;
        if (existing && existing !== letters[i]) {
          ok = false;
          break;
        }
        cells.push({ r: rr, c: cc });
      }
      if (!ok) continue;
      letters.forEach((ch, i) => {
        const cell = cells[i]!;
        grid[cell.r]![cell.c] = ch;
      });
      placed.push({ id: item.id, word: item.wrong, cells });
      done = true;
    }
  }

  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      if (!grid[r]![c]) {
        grid[r]![c] = BEDIN_FILLERS[Math.floor(rng() * BEDIN_FILLERS.length)]!;
      }
    }
  }

  return { size, grid, placed };
}

export function cellsEqual(a: GridCell[], b: GridCell[]): boolean {
  if (a.length !== b.length) return false;
  const key = (list: GridCell[]) => list.map((x) => `${x.r},${x.c}`).join("|");
  const ka = key(a);
  const kb = key(b);
  const kr = key([...a].reverse());
  return ka === kb || kr === kb;
}

export function lineBetween(a: GridCell, b: GridCell): GridCell[] | null {
  const dr = Math.sign(b.r - a.r);
  const dc = Math.sign(b.c - a.c);
  const sameRow = a.r === b.r;
  const sameCol = a.c === b.c;
  const diag = Math.abs(b.r - a.r) === Math.abs(b.c - a.c);
  if (!sameRow && !sameCol && !diag) return null;
  const steps = Math.max(Math.abs(b.r - a.r), Math.abs(b.c - a.c));
  const cells: GridCell[] = [];
  for (let i = 0; i <= steps; i++) {
    cells.push({ r: a.r + dr * i, c: a.c + dc * i });
  }
  return cells;
}
