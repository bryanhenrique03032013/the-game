export function mulberry32(seed: number) {
  let t = seed >>> 0;
  return () => {
    t += 0x6d2b79f5;
    let x = t;
    x = Math.imul(x ^ (x >>> 15), x | 1);
    x ^= x + Math.imul(x ^ (x >>> 7), x | 61);
    return ((x ^ (x >>> 14)) >>> 0) / 4294967296;
  };
}

export function freshSeed(): number {
  const a = Date.now() >>> 0;
  const b = Math.floor(Math.random() * 0xffffffff) >>> 0;
  return (a ^ b) >>> 0;
}

export function shuffle<T>(items: T[], seed = freshSeed()): T[] {
  const rng = mulberry32(seed);
  const next = [...items];
  for (let i = next.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = next[i]!;
    next[i] = next[j]!;
    next[j] = tmp;
  }
  return next;
}

export function pickFresh<T extends { id: string }>(
  pool: T[],
  count: number,
  avoid: string[] = [],
  seed = freshSeed(),
): T[] {
  const blocked = new Set(avoid);
  const fresh = pool.filter((item) => !blocked.has(item.id));
  const source = fresh.length >= count ? fresh : pool;
  return shuffle(source, seed).slice(0, Math.min(count, source.length));
}

export function pickByLevel<T extends { tier: 1 | 2 | 3 }>(
  pool: T[],
  level: "iniciante" | "intermediario" | "avancado",
): T[] {
  if (level === "iniciante") return pool.filter((item) => item.tier === 1);
  if (level === "intermediario") return pool.filter((item) => item.tier <= 2);
  return pool;
}
