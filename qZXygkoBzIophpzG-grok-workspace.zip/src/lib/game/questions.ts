export type AnneItem = {
  id: string;
  tier: 1 | 2 | 3;
  words: { t: string; bad?: boolean }[];
  fix: string;
  why: string;
  clue: string;
};

export type BryanItem = {
  id: string;
  tier: 1 | 2 | 3;
  topic: string;
  realHeadline: string;
  realBody: string;
  realSource: string;
  fakeHeadline: string;
  fakeBody: string;
  tell: string;
  clue: string;
};

export type BedinWord = {
  id: string;
  tier: 1 | 2 | 3;
  wrong: string;
  right: string;
  why: string;
  clue: string;
};

export type LiviaItem = {
  id: string;
  tier: 1 | 2 | 3;
  prompt: string;
  options: string[];
  correct: number;
  why: string;
  clue: string;
};

export type FinalCase = {
  id: string;
  title: string;
  brief: string;
  parts: [string, string, string, string];
  slots: { options: string[]; correct: string }[];
  closing: string;
};

export const ANNE: AnneItem[] = [
  {
    id: "a1",
    tier: 1,
    words: [
      { t: "Haviam", bad: true },
      { t: "muitas" },
      { t: "pistas" },
      { t: "no" },
      { t: "corredor." },
    ],
    fix: "Havia muitas pistas no corredor.",
    why: "Haver no sentido de existir é impessoal: fica no singular. Prenda HAVIAM.",
    clue: "Havia muitas pistas no corredor da delegacia.",
  },
  {
    id: "a2",
    tier: 1,
    words: [
      { t: "Fazem", bad: true },
      { t: "dois" },
      { t: "anos" },
      { t: "que" },
      { t: "o" },
      { t: "caso" },
      { t: "começou." },
    ],
    fix: "Faz dois anos que o caso começou.",
    why: "Fazer indicando tempo decorrido é impessoal: FAZ, nunca FAZEM.",
    clue: "Faz dois anos que o dossiê foi aberto.",
  },
  {
    id: "a3",
    tier: 1,
    words: [
      { t: "A" },
      { t: "gente" },
      { t: "fomos", bad: true },
      { t: "até" },
      { t: "o" },
      { t: "arquivo." },
    ],
    fix: "A gente foi até o arquivo.",
    why: "A gente pede verbo no singular: A GENTE FOI.",
    clue: "A gente foi até o arquivo sigiloso.",
  },
  {
    id: "a4",
    tier: 1,
    words: [
      { t: "Houveram", bad: true },
      { t: "vários" },
      { t: "depoimentos" },
      { t: "falsos." },
    ],
    fix: "Houve vários depoimentos falsos.",
    why: "Haver = existir → HOUVE, mesmo com ideia de plural.",
    clue: "Houve vários depoimentos contraditórios.",
  },
  {
    id: "a5",
    tier: 1,
    words: [
      { t: "A" },
      { t: "polícia" },
      { t: "chegaram", bad: true },
      { t: "cedo" },
      { t: "na" },
      { t: "cena." },
    ],
    fix: "A polícia chegou cedo na cena.",
    why: "Polícia é substantivo coletivo singular: A POLÍCIA CHEGOU.",
    clue: "A polícia chegou cedo demais para o suspeito.",
  },
  {
    id: "a6",
    tier: 1,
    words: [
      { t: "Fazem", bad: true },
      { t: "falta" },
      { t: "as" },
      { t: "testemunhas." },
    ],
    fix: "Faz falta as testemunhas.",
    why: "Fazer falta é impessoal: FAZ FALTA.",
    clue: "Faz falta um laudo completo no processo.",
  },
  {
    id: "a7",
    tier: 1,
    words: [
      { t: "Os" },
      { t: "aluno", bad: true },
      { t: "copiaram" },
      { t: "a" },
      { t: "frase" },
      { t: "errada." },
    ],
    fix: "Os alunos copiaram a frase errada.",
    why: "Artigo plural pede substantivo plural: OS ALUNOS.",
    clue: "Os alunos copiaram o relatório sem conferir.",
  },
  {
    id: "a8",
    tier: 1,
    words: [
      { t: "Haviam", bad: true },
      { t: "erros" },
      { t: "no" },
      { t: "relatório" },
      { t: "oficial." },
    ],
    fix: "Havia erros no relatório oficial.",
    why: "De novo: existir = HAVIA, no singular.",
    clue: "Havia erros graves no relatório oficial.",
  },
  {
    id: "a9",
    tier: 2,
    words: [
      { t: "Assisti" },
      { t: "o", bad: true },
      { t: "depoimento" },
      { t: "completo." },
    ],
    fix: "Assisti ao depoimento completo.",
    why: "Assistir no sentido de ver/presenciar pede a: ASSISTI AO.",
    clue: "Assisti ao depoimento completo da testemunha.",
  },
  {
    id: "a10",
    tier: 2,
    words: [
      { t: "Prefiro" },
      { t: "gramática" },
      { t: "do", bad: true },
      { t: "que" },
      { t: "química." },
    ],
    fix: "Prefiro gramática a química.",
    why: "Preferir rege a, não do que: PREFIRO X A Y.",
    clue: "Prefiro a verdade a um texto bonito e falso.",
  },
  {
    id: "a11",
    tier: 2,
    words: [
      { t: "Tratam-se", bad: true },
      { t: "de" },
      { t: "provas" },
      { t: "falsas." },
    ],
    fix: "Trata-se de provas falsas.",
    why: "Tratar-se de é impessoal: TRATA-SE DE, no singular.",
    clue: "Trata-se de provas adulteradas no inquérito.",
  },
  {
    id: "a12",
    tier: 2,
    words: [
      { t: "Havia", bad: true },
      { t: "chegado" },
      { t: "os" },
      { t: "peritos." },
    ],
    fix: "Haviam chegado os peritos.",
    why: "Aqui HAVER é auxiliar de chegar: concorda com o sujeito OS PERITOS.",
    clue: "Haviam chegado os peritos quando o chefe ligou.",
  },
  {
    id: "a13",
    tier: 2,
    words: [
      { t: "O" },
      { t: "diretor" },
      { t: "e" },
      { t: "o" },
      { t: "secretário" },
      { t: "chegou", bad: true },
      { t: "juntos." },
    ],
    fix: "O diretor e o secretário chegaram juntos.",
    why: "Dois núcleos no sujeito: verbo no plural, CHEGARAM.",
    clue: "O diretor e o secretário chegaram juntos ao gabinete.",
  },
  {
    id: "a14",
    tier: 2,
    words: [
      { t: "Fui" },
      { t: "no", bad: true },
      { t: "fórum" },
      { t: "ontem" },
      { t: "de" },
      { t: "manhã." },
    ],
    fix: "Fui ao fórum ontem de manhã.",
    why: "Ir rege a: FUI AO fórum (não fui no).",
    clue: "Fui ao fórum com o dossiê debaixo do braço.",
  },
  {
    id: "a15",
    tier: 2,
    words: [
      { t: "Choveu", bad: true },
      { t: "documentos" },
      { t: "no" },
      { t: "gabinete." },
    ],
    fix: "Choveram documentos no gabinete.",
    why: "Quando chover tem sujeito (documentos), o verbo concorda: CHOVERAM.",
    clue: "Choveram documentos anônimos no gabinete.",
  },
  {
    id: "a16",
    tier: 2,
    words: [
      { t: "Informei" },
      { t: "ele", bad: true },
      { t: "o" },
      { t: "resultado" },
      { t: "do" },
      { t: "exame." },
    ],
    fix: "Informei-lhe o resultado do exame.",
    why: "Informar alguém de algo: o complemento de pessoa é lhe, não ele.",
    clue: "Informei-lhe o resultado antes do plantão.",
  },
  {
    id: "a17",
    tier: 3,
    words: [
      { t: "Obedeço" },
      { t: "os", bad: true },
      { t: "regulamentos" },
      { t: "da" },
      { t: "casa." },
    ],
    fix: "Obedeço aos regulamentos da casa.",
    why: "Obedecer é transitivo indireto: OBEDECER A.",
    clue: "Obedeço aos regulamentos mesmo quando o caso aperta.",
  },
  {
    id: "a18",
    tier: 3,
    words: [
      { t: "Aspiro" },
      { t: "o", bad: true },
      { t: "cargo" },
      { t: "de" },
      { t: "delegado." },
    ],
    fix: "Aspiro ao cargo de delegado.",
    why: "Aspirar = almejar pede a: ASPIRO AO CARGO.",
    clue: "Aspiro ao cargo de delegado da língua.",
  },
  {
    id: "a19",
    tier: 3,
    words: [
      { t: "Visamos" },
      { t: "o", bad: true },
      { t: "cargo" },
      { t: "desde" },
      { t: "o" },
      { t: "estágio." },
    ],
    fix: "Visamos ao cargo desde o estágio.",
    why: "Visar = almejar é transitivo indireto: VISAR A.",
    clue: "Visamos à nota máxima no relatório final.",
  },
  {
    id: "a20",
    tier: 3,
    words: [
      { t: "Haverão", bad: true },
      { t: "novidades" },
      { t: "amanhã" },
      { t: "cedo." },
    ],
    fix: "Haverá novidades amanhã cedo.",
    why: "Haver = existir permanece no singular: HAVERÁ.",
    clue: "Haverá novidades amanhã no gabinete da chefe.",
  },
  {
    id: "a21",
    tier: 3,
    words: [
      { t: "Bateu", bad: true },
      { t: "três" },
      { t: "horas" },
      { t: "no" },
      { t: "relógio" },
      { t: "da" },
      { t: "entrada." },
    ],
    fix: "Bateram três horas no relógio da entrada.",
    why: "O sujeito é três horas: BATERAM TRÊS HORAS.",
    clue: "Bateram três horas quando o carimbo bateu na mesa.",
  },
  {
    id: "a22",
    tier: 3,
    words: [
      { t: "Os" },
      { t: "Estados" },
      { t: "Unidos" },
      { t: "é", bad: true },
      { t: "uma" },
      { t: "referência" },
      { t: "no" },
      { t: "inquérito." },
    ],
    fix: "Os Estados Unidos são uma referência no inquérito.",
    why: "Nomes geográficos no plural com artigo: OS ESTADOS UNIDOS SÃO.",
    clue: "Os arquivos internacionais são só uma pista, não a sentença.",
  },
  {
    id: "a23",
    tier: 3,
    words: [
      { t: "Simpatizo" },
      { t: "os", bad: true },
      { t: "colegas" },
      { t: "do" },
      { t: "plantão." },
    ],
    fix: "Simpatizo com os colegas do plantão.",
    why: "Simpatizar exige com: SIMPATIZAR COM.",
    clue: "Simpatizo com os colegas que revisam cada linha.",
  },
  {
    id: "a24",
    tier: 3,
    words: [
      { t: "Implico" },
      { t: "os", bad: true },
      { t: "colegas" },
      { t: "sem" },
      { t: "motivo." },
    ],
    fix: "Implico com os colegas sem motivo.",
    why: "Implicar no sentido de ter implicância pede a preposição COM.",
    clue: "Quem implica com o texto não lê a pista até o fim.",
  },
];

export const BRYAN: BryanItem[] = [
  {
    id: "b1",
    tier: 1,
    topic: "Volta às aulas",
    realHeadline: "Aulas municipais voltam no dia 18, diz secretaria",
    realBody:
      "A Secretaria Municipal de Educação confirmou, em nota nesta terça (12), que as escolas da rede reabrem no dia 18. O calendário está no site oficial da pasta.",
    realSource: "Nota da Secretaria Municipal de Educação, 12/03",
    fakeHeadline: "URGENTE: escolas NÃO voltam NUNCA mais",
    fakeBody:
      "Um professor misterioso vazou que as aulas acabaram para sempre. Compartilha antes que apaguem!!! Fonte: um grupo da internet.",
    tell: "A falsa não tem fonte verificável, data precisa nem linguagem responsável.",
    clue: "A nota oficial citava a secretaria e a data da volta.",
  },
  {
    id: "b2",
    tier: 1,
    topic: "Enem",
    realHeadline: "Inep divulga datas do Enem no Diário Oficial",
    realBody:
      "O Instituto Nacional de Estudos e Pesquisas Educacionais (Inep) publicou o edital com as datas das provas. O documento está no portal gov.br.",
    realSource: "Edital Inep / Diário Oficial",
    fakeHeadline: "Enem foi CANCELADO e ninguém te contou",
    fakeBody:
      "Acabei de saber de um primo de um amigo: o Enem acabou. Não tem link, não tem órgão, mas é verdade porque viralizou.",
    tell: "Sem órgão, sem edital, sem link: rumor, não notícia.",
    clue: "Só o edital do Inep vale como prova de data.",
  },
  {
    id: "b3",
    tier: 1,
    topic: "Biblioteca",
    realHeadline: "Biblioteca da escola reabre após reforma, afirma direção",
    realBody:
      "A direção da Escola Estadual Castro Alves informou que a biblioteca reabre na segunda, das 8h às 17h. O comunicado foi afixado no mural e enviado aos responsáveis.",
    realSource: "Comunicado da direção, mural oficial",
    fakeHeadline: "Biblioteca virou pista de dança secreta à meia-noite",
    fakeBody:
      "Vários alunos (ninguém citado) juram que a biblioteca abre à noite para festas. Fotos? Nenhuma. Nome? Nenhum.",
    tell: "A real tem instituição, horário e canal oficial. A fake é boato anônimo.",
    clue: "O comunicado da direção tinha horário e mural oficial.",
  },
  {
    id: "b4",
    tier: 2,
    topic: "Gripe na escola",
    realHeadline: "Surto de gripe leva 12% da turma ao atestado, diz posto",
    realBody:
      "A unidade básica do bairro registrou aumento de 12% nos atestados de síndromes gripais na semana. A informação consta no boletim da vigilância em saúde.",
    realSource: "Boletim da Vigilância em Saúde, semana 14",
    fakeHeadline: "TODO MUNDO vai pegar uma super gripe mortal amanhã",
    fakeBody:
      "Especialistas (quais?) alertam que ninguém escapa. Não citei estudo porque 'todo mundo sabe'. Pânico agora.",
    tell: "Percentual + boletim = dado. 'Todo mundo / mortal / amanhã' sem estudo = clickbait.",
    clue: "O boletim falava em 12%, não em pânico.",
  },
  {
    id: "b5",
    tier: 2,
    topic: "Olimpíada de português",
    realHeadline: "Aluna da casa fica em 3º na olimpíada estadual de língua",
    realBody:
      "A Secretaria de Educação divulgou a lista de premiados. Ana Ribeiro, 2º ano, ficou em 3º lugar. A lista oficial traz nome, escola e pontuação.",
    realSource: "Lista oficial da Secretaria de Educação",
    fakeHeadline: "Nossa escola GANHOU TUDO e vai receber um milhão",
    fakeBody:
      "Fontes próximas da direção (sem nome) dizem que somos campeões absolutos e que o prêmio em dinheiro já caiu. Confia.",
    tell: "A verdadeira traz nome, lugar e lista. A falsa infla prêmio e esconde a fonte.",
    clue: "A lista oficial trazia nome, escola e pontuação.",
  },
  {
    id: "b6",
    tier: 2,
    topic: "Internet na sala",
    realHeadline: "Rede wi-fi pedagógica entra no ar em quatro salas-piloto",
    realBody:
      "O projeto-piloto, anunciado em reunião de pais na quinta, cobre as salas 3, 5, 8 e 12. A ata da reunião registra o cronograma.",
    realSource: "Ata da reunião de pais, 08/05",
    fakeHeadline: "Proibiram o celular PARA SEMPRE em TODO o país",
    fakeBody:
      "Uma lei secreta (número? data? casa legislativa?) teria banido celulares. Vi no status de desconhecido.",
    tell: "Ata, data e recorte (quatro salas) contra lei secreta sem número.",
    clue: "A ata da reunião delimitava o piloto a quatro salas.",
  },
  {
    id: "b7",
    tier: 3,
    topic: "Redação nota 1000",
    realHeadline: "Inep explica os critérios da competência 4 da redação",
    realBody:
      "A Cartilha do Participante detalha que a competência 4 avalia conectivos e articulação. O PDF está no site do Enem, com exemplos de 0 a 200 pontos.",
    realSource: "Cartilha do Participante — Inep",
    fakeHeadline: "Fórmula SECRETA da nota 1000: copie este modelo pronto",
    fakeBody:
      "Um perfil anônimo garante 1000 se você colar o texto. Sem autor, sem edição do Inep, sem evidência — só promessa.",
    tell: "Cartilha oficial versus modelo milagroso de perfil anônimo.",
    clue: "A cartilha do Inep descreve a competência 4 com exemplos.",
  },
  {
    id: "b8",
    tier: 3,
    topic: "Greve de ônibus",
    realHeadline: "Sindicato confirma paralisação das 6h às 9h na sexta",
    realBody:
      "O sindicato dos rodoviários publicou comunicado com horário, linhas afetadas e canal de imprensa. A prefeitura replicou o aviso no site.",
    realSource: "Comunicado do sindicato + site da prefeitura",
    fakeHeadline: "Cidade INTEIRA vai parar e o governo esconde",
    fakeBody:
      "Paralisação eterna, sem hora, sem linha, sem porta-voz. 'Confia no que o primo mandou no grupo.'",
    tell: "Horário, linhas e dois canais oficiais versus generalização sem porta-voz.",
    clue: "O comunicado do sindicato trazia horário e linhas afetadas.",
  },
  {
    id: "b9",
    tier: 3,
    topic: "Livro didático",
    realHeadline: "MEC divulga obras aprovadas no PNLD 2026",
    realBody:
      "A lista de livros aprovados no Programa Nacional do Livro e do Material Didático saiu no portal do ministério, com código e editora de cada coleção.",
    realSource: "Portal do MEC / PNLD",
    fakeHeadline: "Governo VAI QUEIMAR todos os livros de português",
    fakeBody:
      "Imagem de arquivo, manchete gritante, zero documento. O texto pede para compartilhar 'antes que a mídia apague'.",
    tell: "Pedido de pânico + imagem de arquivo + nenhum PDF oficial = desinformação.",
    clue: "A lista do PNLD traz código e editora, não fumaça.",
  },
  {
    id: "b10",
    tier: 1,
    topic: "Feira de ciências",
    realHeadline: "Feira de ciências será sábado, 9h, no pátio coberto",
    realBody:
      "A coordenação pedagógica enviou circular n.º 14 aos responsáveis, com data, hora, local e lista de projetos. O documento está na secretaria.",
    realSource: "Circular n.º 14 da coordenação",
    fakeHeadline: "Feira foi PROIBIDA porque os projetos são perigosos",
    fakeBody:
      "Dizem por aí que explosões vão acontecer. Ninguém da escola confirmou. Melhor espalhar mesmo assim.",
    tell: "Circular numerada contra 'dizem por aí'.",
    clue: "A circular n.º 14 marcava sábado, 9h, no pátio.",
  },
  {
    id: "b11",
    tier: 2,
    topic: "Bolsa de estudo",
    realHeadline: "Inscrições para bolsa de iniciação abrem dia 2, no site da universidade",
    realBody:
      "O edital 42/2026 da pró-reitoria de graduação define vagas, prazo e documentos. Inscrição só pelo formulário institucional.",
    realSource: "Edital 42/2026 — Pró-reitoria",
    fakeHeadline: "Clique AQUI e ganhe bolsa SEM prova, SEM documento",
    fakeBody:
      "Link encurtado, promessa milagrosa, pedido de dados pessoais. Sem universidade identificada.",
    tell: "Edital com número versus link milagroso que pede dados.",
    clue: "Só o edital 42/2026 abre a inscrição institucional.",
  },
  {
    id: "b12",
    tier: 3,
    topic: "IA na redação",
    realHeadline: "Banca do Enem penaliza trecho comprovadamente copiado, reafirma Inep",
    realBody:
      "Em entrevista ao jornal Folha, a diretoria de avaliação do Inep reiterou que plágio e trechos idênticos a modelos prontos zeram a competência 5. A fala está na edição de 04/06.",
    realSource: "Folha de S.Paulo, 04/06, entrevista ao Inep",
    fakeHeadline: "IA GARANTE 1000 e a banca NEM PERCEBE, diz guru",
    fakeBody:
      "Um 'especialista em Enem' sem filiação acadêmica vende curso. Nenhuma banca, nenhum estudo, só depoimento pago.",
    tell: "Veículo + data + cargo citado versus guru sem filiação vendendo milagre.",
    clue: "A entrevista do Inep falava em penalidade para modelo pronto.",
  },
];

export const BEDIN: BedinWord[] = [
  {
    id: "d1",
    tier: 1,
    wrong: "AGENTE",
    right: "a gente",
    why: "A GENTE (nós) se escreve separado. AGENTE é profissional.",
    clue: "A gente escreve separado quando significa nós.",
  },
  {
    id: "d2",
    tier: 1,
    wrong: "MAIS",
    right: "mas",
    why: "MAS é adversativo (porém). MAIS é quantidade.",
    clue: "Mas é adversativo; mais é quantidade.",
  },
  {
    id: "d3",
    tier: 1,
    wrong: "MAL",
    right: "mau",
    why: "MAU é o contrário de bom. MAL é o contrário de bem.",
    clue: "Mau é o contrário de bom; mal, de bem.",
  },
  {
    id: "d4",
    tier: 1,
    wrong: "PORQUE",
    right: "por que",
    why: "Em pergunta, POR QUE se separa. PORQUE responde.",
    clue: "Por que se separa na pergunta.",
  },
  {
    id: "d5",
    tier: 1,
    wrong: "ESTA",
    right: "está",
    why: "ESTÁ (verbo estar) leva acento. ESTA é pronome demonstrativo.",
    clue: "O dossiê está na mesa da chefe.",
  },
  {
    id: "d6",
    tier: 2,
    wrong: "AFIM",
    right: "a fim",
    why: "A FIM DE = para. AFIM = parecido, afinidade.",
    clue: "Estávamos a fim de fechar o inquérito.",
  },
  {
    id: "d7",
    tier: 2,
    wrong: "DEMAIS",
    right: "de mais",
    why: "DE MAIS = a mais, extra. DEMAIS = excessivamente.",
    clue: "Não havia nada de mais na gaveta.",
  },
  {
    id: "d8",
    tier: 2,
    wrong: "SENAO",
    right: "se não",
    why: "SE NÃO = caso não. SENÃO = caso contrário / a não ser.",
    clue: "Se não chover, o plantão segue na rua.",
  },
  {
    id: "d9",
    tier: 2,
    wrong: "ONDE",
    right: "aonde",
    why: "AONDE indica movimento (a + onde). ONDE é lugar estático.",
    clue: "Aonde vai o dossiê depois do carimbo?",
  },
  {
    id: "d10",
    tier: 2,
    wrong: "TRAS",
    right: "traz",
    why: "TRAZ vem de trazer. TRÁS é atrás, para trás.",
    clue: "Quem traz a prova fecha o caso.",
  },
  {
    id: "d11",
    tier: 3,
    wrong: "SESSAO",
    right: "seção",
    why: "SEÇÃO = setor. SESSÃO = reunião. CESSÃO = ato de ceder.",
    clue: "A seção de arquivos guarda o original.",
  },
  {
    id: "d12",
    tier: 3,
    wrong: "CEM",
    right: "sem",
    why: "SEM = falta. CEM = 100. O erro esconde a preposição.",
    clue: "O texto veio sem conectivos.",
  },
  {
    id: "d13",
    tier: 3,
    wrong: "MAS",
    right: "mais",
    why: "Aqui a frase pedia quantidade: MAIS pistas, não MAS pistas.",
    clue: "Precisávamos de mais pistas, não de desculpas.",
  },
  {
    id: "d14",
    tier: 3,
    wrong: "DESPERCEBIDO",
    right: "desapercebido",
    why: "DESPERCEBIDO = não notado. DESAPERCEBIDO = desprevenido.",
    clue: "O erro passou despercebido na primeira leitura.",
  },
  {
    id: "d15",
    tier: 1,
    wrong: "MUNTO",
    right: "muito",
    why: "MUITO se escreve com I. MUNTO não existe na língua.",
    clue: "Havia muito trabalho no quadro-negro.",
  },
  {
    id: "d16",
    tier: 2,
    wrong: "ACERCA",
    right: "há cerca",
    why: "ACERCA DE = sobre. HÁ CERCA DE = faz aproximadamente.",
    clue: "Há cerca de uma hora o carimbo sumiu.",
  },
];

export const LIVIA: LiviaItem[] = [
  {
    id: "l1",
    tier: 1,
    prompt: "Os detetives chegaram no entanto a sala estava vazia.",
    options: [
      "Os detetives chegaram; no entanto, a sala estava vazia.",
      "Os detetives chegaram no entanto, a sala estava vazia.",
      "Os detetives chegaram no entanto a sala, estava vazia.",
    ],
    correct: 0,
    why: "Conectivo adversativo no meio pede ponto e vírgula (ou ponto) antes e vírgula depois.",
    clue: "No entanto pede pausa forte antes e vírgula depois.",
  },
  {
    id: "l2",
    tier: 1,
    prompt: "Fui a escola buscar o dossiê.",
    options: [
      "Fui à escola buscar o dossiê.",
      "Fui a escola buscar o dossiê.",
      "Fui á escola buscar o dossiê.",
    ],
    correct: 0,
    why: "A preposição a + artigo a = crase: FUI À ESCOLA.",
    clue: "Fui à escola buscar o dossiê.",
  },
  {
    id: "l3",
    tier: 1,
    prompt: "Delegada o caso está pronto.",
    options: [
      "Delegada, o caso está pronto.",
      "Delegada o caso, está pronto.",
      "Delegada o caso está, pronto.",
    ],
    correct: 0,
    why: "Vocativo se separa por vírgula: DELEGADA, ...",
    clue: "O vocativo pede vírgula: Delegada, o caso está pronto.",
  },
  {
    id: "l4",
    tier: 1,
    prompt: "As 15h o chefe chegou.",
    options: [
      "Às 15h, o chefe chegou.",
      "As 15h, o chefe chegou.",
      "Ás 15h o chefe chegou.",
    ],
    correct: 0,
    why: "Horas com a: ÀS 15H. Vírgula após adjunto deslocado é recomendada.",
    clue: "Às 15h, o chefe chegou ao gabinete.",
  },
  {
    id: "l5",
    tier: 2,
    prompt: "Entregue o relatório a ela agora.",
    options: [
      "Entregue o relatório a ela agora.",
      "Entregue o relatório à ela agora.",
      "Entregue o relatório à ela, agora.",
    ],
    correct: 0,
    why: "Não há crase antes de pronome pessoal: A ELA.",
    clue: "Não há crase antes de pronome pessoal: a ela.",
  },
  {
    id: "l6",
    tier: 2,
    prompt: "Vou a Bahia amanhã com o inquérito.",
    options: [
      "Vou à Bahia amanhã com o inquérito.",
      "Vou a Bahia amanhã com o inquérito.",
      "Vou á Bahia amanhã com o inquérito.",
    ],
    correct: 0,
    why: "Nomes de lugares femininos que admitem a: VOU À BAHIA.",
    clue: "Vou à Bahia com o inquérito sob o braço.",
  },
  {
    id: "l7",
    tier: 2,
    prompt: "Sim João nós precisamos da vírgula.",
    options: [
      "Sim, João, nós precisamos da vírgula.",
      "Sim João, nós precisamos da vírgula.",
      "Sim João nós, precisamos da vírgula.",
    ],
    correct: 0,
    why: "Sim isolado e vocativo JOÃO pedem vírgulas.",
    clue: "Sim, João, a vírgula prende o vocativo.",
  },
  {
    id: "l8",
    tier: 2,
    prompt: "O suspeito que mentiu foi ouvido de novo.",
    options: [
      "O suspeito que mentiu foi ouvido de novo.",
      "O suspeito, que mentiu, foi ouvido de novo.",
      "O suspeito que mentiu, foi ouvido de novo.",
    ],
    correct: 0,
    why: "Restritiva (que mentiu = qual deles) NÃO leva vírgula.",
    clue: "Oração restritiva não leva vírgula.",
  },
  {
    id: "l9",
    tier: 3,
    prompt: "Os peritos chegaram cedo o laudo porém só saiu à noite.",
    options: [
      "Os peritos chegaram cedo; o laudo, porém, só saiu à noite.",
      "Os peritos chegaram cedo o laudo porém, só saiu à noite.",
      "Os peritos chegaram, cedo o laudo porém só saiu à noite.",
    ],
    correct: 0,
    why: "Duas orações independentes: ponto e vírgula. PORÉM deslocado: entre vírgulas. À NOITE: crase.",
    clue: "Porém deslocado vive entre vírgulas.",
  },
  {
    id: "l10",
    tier: 3,
    prompt: "Refiro-me a fatos ocorridos a epoca do Enem.",
    options: [
      "Refiro-me a fatos ocorridos à época do Enem.",
      "Refiro-me à fatos ocorridos a época do Enem.",
      "Refiro-me a fatos ocorridos a época do Enem.",
    ],
    correct: 0,
    why: "A FATOS: masculino plural, sem crase. À ÉPOCA: a + a.",
    clue: "À época do Enem o texto ainda não tinha conectivo.",
  },
  {
    id: "l11",
    tier: 3,
    prompt: "Chefe Manuella pediu clareza coesão e concisão.",
    options: [
      "Chefe Manuella pediu clareza, coesão e concisão.",
      "Chefe, Manuella pediu clareza coesão e concisão.",
      "Chefe Manuella, pediu clareza, coesão, e concisão.",
    ],
    correct: 0,
    why: "Enumerações levam vírgula entre os termos (sem vírgula obrigatória antes de e).",
    clue: "Clareza, coesão e concisão fecham o relatório.",
  },
  {
    id: "l12",
    tier: 1,
    prompt: "Quando o carimbo caiu todos respiraram.",
    options: [
      "Quando o carimbo caiu, todos respiraram.",
      "Quando, o carimbo caiu todos respiraram.",
      "Quando o carimbo, caiu todos respiraram.",
    ],
    correct: 0,
    why: "Oração adverbial anteposta: vírgula depois.",
    clue: "Quando o carimbo caiu, todos respiraram.",
  },
  {
    id: "l13",
    tier: 2,
    prompt: "O relatório que estava na mesa desapareceu.",
    options: [
      "O relatório que estava na mesa desapareceu.",
      "O relatório, que estava na mesa desapareceu.",
      "O relatório que estava, na mesa desapareceu.",
    ],
    correct: 0,
    why: "Restritiva outra vez: sem vírgula, identifica QUAL relatório.",
    clue: "O relatório que estava na mesa desapareceu.",
  },
  {
    id: "l14",
    tier: 3,
    prompt: "Assistimos a peça as escondidas.",
    options: [
      "Assistimos à peça às escondidas.",
      "Assistimos a peça as escondidas.",
      "Assistimos à peça as escondidas.",
    ],
    correct: 0,
    why: "Assistir a + a peça = À PEÇA. ÀS ESCONDIDAS é locução feminina.",
    clue: "Assistimos à peça às escondidas, sem fonte na plateia.",
  },
  {
    id: "l15",
    tier: 3,
    prompt: "Nao foi a toa que a banca zerou o parágrafo.",
    options: [
      "Não foi à toa que a banca zerou o parágrafo.",
      "Não foi a toa que a banca zerou o parágrafo.",
      "Não foi á toa, que a banca zerou o parágrafo.",
    ],
    correct: 0,
    why: "Locução adverbial feminina: À TOA.",
    clue: "Não foi à toa que a banca zerou o parágrafo.",
  },
  {
    id: "l16",
    tier: 2,
    prompt: "Portanto o inquérito segue aberto.",
    options: [
      "Portanto, o inquérito segue aberto.",
      "Portanto o inquérito, segue aberto.",
      "Portanto o inquérito segue, aberto.",
    ],
    correct: 0,
    why: "Conectivo no início: vírgula depois de PORTANTO.",
    clue: "Portanto, o inquérito segue aberto até o parágrafo final.",
  },
];

export const FINALS: FinalCase[] = [
  {
    id: "f1",
    title: "O parágrafo nota zero",
    brief:
      "Um candidato entregou a redação sem conectivos. Una as quatro pistas e reconstrua o parágrafo que a banca espera.",
    parts: [
      "o laudo apontou erro de concordância",
      "a manchete viral não trazia fonte",
      "o texto escondia a troca de mas e mais",
      "a redação pode chegar à nota 1000",
    ],
    slots: [
      {
        options: ["No entanto", "Porque", "Embora"],
        correct: "No entanto",
      },
      {
        options: ["além disso", "apesar de", "a fim de"],
        correct: "além disso",
      },
      {
        options: ["Portanto", "Embora", "Quando"],
        correct: "Portanto",
      },
    ],
    closing: "se os conectivos prenderem cada pista no lugar certo.",
  },
  {
    id: "f2",
    title: "O inquérito desconexo",
    brief:
      "O relatório da equipe saiu aos pedaços. Encaixe os conectivos para a chefe carimbar APROVADO.",
    parts: [
      "havia pistas demais na mesa da Anne",
      "Bryan desmascarou o boato sem data",
      "Bedin prendeu as grafias impostoras",
      "o gabinete considera o caso encerrado",
    ],
    slots: [
      { options: ["Primeiro", "Embora", "Senão"], correct: "Primeiro" },
      { options: ["depois", "apesar", "conforme"], correct: "depois" },
      { options: ["Assim", "Embora", "Caso"], correct: "Assim" },
    ],
    closing: "com o carimbo da chefe Manuella.",
  },
  {
    id: "f3",
    title: "Competência 4 sob investigação",
    brief:
      "A banca do Enem zerou a coesão. Reescreva o parágrafo com articuladores precisos.",
    parts: [
      "a frase inicial estava sem sujeito claro",
      "o segundo argumento repetia o primeiro",
      "faltava crase em locuções femininas",
      "o texto ganha fluidez e nota",
    ],
    slots: [
      { options: ["Além disso", "Apesar", "Aonde"], correct: "Além disso" },
      { options: ["e", "mas não", "se"], correct: "e" },
      { options: ["Dessa forma", "Embora", "Onde"], correct: "Dessa forma" },
    ],
    closing: "na competência 4 da redação.",
  },
  {
    id: "f4",
    title: "Quatro salas, um parágrafo",
    brief:
      "Cada detetive trouxe uma evidência. Sua missão é costurá-las sem deixar o leitor tropeçar.",
    parts: [
      "Anne prendeu o verbo impessoal no singular",
      "a notícia verdadeira citava o órgão",
      "o caça-palavras entregou agente no lugar de a gente",
      "o parágrafo fecha com clareza",
    ],
    slots: [
      { options: ["enquanto", "apesar", "afora"], correct: "enquanto" },
      { options: ["e", "ou seja,", "salvo"], correct: "e" },
      { options: ["Por conseguinte", "Embora", "Senão"], correct: "Por conseguinte" },
    ],
    closing: "e o certificado pode ser emitido.",
  },
  {
    id: "f5",
    title: "Operação conectivo",
    brief:
      "Sem articuladores, as pistas parecem crimes isolados. Ligue-as como um único caso.",
    parts: [
      "o mural da concordância estava coberto de X vermelhos",
      "o jornal de parede recebeu o carimbo FAKE",
      "o quadro-negro escondia mas e mais",
      "a chefe libera o diploma Nota 1000",
    ],
    slots: [
      { options: ["Em seguida", "Embora", "A menos que"], correct: "Em seguida" },
      { options: ["ao mesmo tempo", "apesar de", "salvo se"], correct: "ao mesmo tempo" },
      { options: ["Finalmente", "Caso contrário", "A fim de"], correct: "Finalmente" },
    ],
    closing: "ao detetive que uniu as quatro salas.",
  },
  {
    id: "f6",
    title: "Último plantão da língua",
    brief:
      "O relógio bateu três horas. Monte o parágrafo final antes que o plantão acabe.",
    parts: [
      "os erros de transitividade já estavam presos",
      "a fake news perdeu o disfarce",
      "a pontuação voltou ao relatório",
      "o caso da língua pode ser arquivado",
    ],
    slots: [
      { options: ["e", "embora", "se"], correct: "e" },
      { options: ["depois que", "a menos que", "sem que"], correct: "depois que" },
      { options: ["Logo", "Embora", "Caso"], correct: "Logo" },
    ],
    closing: "com honras de Policial da Língua Portuguesa.",
  },
];

export const BEDIN_FILLERS = "AEIOURSTLNMCDPBGVJFZX";
