let ctx: AudioContext | null = null;

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const Ctor = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    ctx = new Ctor();
  }
  return ctx;
}

export function unlockAudio() {
  const audio = getCtx();
  if (!audio) return;
  if (audio.state === "suspended") void audio.resume();
}

function beep(freq: number, dur: number, type: OscillatorType, gain = 0.05, delay = 0) {
  const audio = getCtx();
  if (!audio) return;
  const now = audio.currentTime + delay;
  const osc = audio.createOscillator();
  const g = audio.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, now);
  g.gain.setValueAtTime(gain, now);
  g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
  osc.connect(g);
  g.connect(audio.destination);
  osc.start(now);
  osc.stop(now + dur + 0.02);
}

export const sfx = {
  stamp() {
    beep(90, 0.12, "square", 0.07);
    beep(180, 0.08, "triangle", 0.04, 0.04);
  },
  ok() {
    beep(520, 0.08, "triangle", 0.05);
    beep(740, 0.1, "triangle", 0.04, 0.07);
  },
  bad() {
    beep(180, 0.14, "sawtooth", 0.04);
  },
  tick() {
    beep(420, 0.03, "square", 0.025);
  },
  win() {
    beep(523, 0.1, "triangle", 0.05);
    beep(659, 0.1, "triangle", 0.05, 0.1);
    beep(784, 0.16, "triangle", 0.05, 0.2);
  },
};
