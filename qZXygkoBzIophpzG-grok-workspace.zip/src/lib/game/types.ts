export const LEVELS = ["iniciante", "intermediario", "avancado"] as const;
export type Level = (typeof LEVELS)[number];

export const CASE_IDS = ["anne", "bryan", "bedin", "livia", "manuella"] as const;
export type CaseId = (typeof CASE_IDS)[number];

export type CaseMeta = {
  id: CaseId;
  detective: string;
  title: string;
  crime: string;
  desk: string;
  lockedUntil?: CaseId[];
};

export const CASES: CaseMeta[] = [
  {
    id: "anne",
    detective: "Anne",
    title: "Detetive da Concordância",
    crime: "Frases com erro de concordância e transitividade",
    desk: "Sala 1 · Lupa e mural de frases",
  },
  {
    id: "bryan",
    detective: "Bryan",
    title: "Detetive do Fake News",
    crime: "Notícia sem fonte, argumento ou data",
    desk: "Sala 2 · Jornal de parede",
  },
  {
    id: "bedin",
    detective: "Bedin",
    title: "Detetive Ortográfico",
    crime: "Palavras escritas errado no meio do texto",
    desk: "Sala 3 · Quadro-negro e caça-palavras",
  },
  {
    id: "livia",
    detective: "Lívia",
    title: "Detetive da Pontuação",
    crime: "Vírgulas, crases e pontos desaparecidos",
    desk: "Sala 4 · Máquina de escrever",
  },
  {
    id: "manuella",
    detective: "Manuella",
    title: "Chefe da Delegacia",
    crime: "Redação sem conectivos — o caso final",
    desk: "Gabinete · Carimbo APROVADO",
    lockedUntil: ["anne", "bryan", "bedin", "livia"],
  },
];

export type CaseProgress = {
  completed: boolean;
  stars: number;
  bestScore: number;
  clue: string | null;
  attempts: number;
};

export type Profile = {
  badgeName: string;
  level: Level;
  xp: number;
  seenBriefing: boolean;
  cases: Record<CaseId, CaseProgress>;
  certified: boolean;
  certificateScore: number;
};

export function emptyCase(): CaseProgress {
  return {
    completed: false,
    stars: 0,
    bestScore: 0,
    clue: null,
    attempts: 0,
  };
}

export function emptyProfile(badgeName = "Detetive"): Profile {
  return {
    badgeName,
    level: "iniciante",
    xp: 0,
    seenBriefing: false,
    cases: {
      anne: emptyCase(),
      bryan: emptyCase(),
      bedin: emptyCase(),
      livia: emptyCase(),
      manuella: emptyCase(),
    },
    certified: false,
    certificateScore: 0,
  };
}

export function levelLabel(level: Level): string {
  if (level === "iniciante") return "Iniciante";
  if (level === "intermediario") return "Intermediário";
  return "Avançado";
}

export function rankForXp(xp: number): string {
  if (xp >= 700) return "Delegado adjunto";
  if (xp >= 450) return "Inspetor";
  if (xp >= 250) return "Detetive";
  if (xp >= 100) return "Detetive júnior";
  return "Recruta";
}

export function roundCount(level: Level, kind: "anne" | "bryan" | "bedin" | "livia"): number {
  if (kind === "anne") {
    if (level === "iniciante") return 5;
    if (level === "intermediario") return 7;
    return 10;
  }
  if (kind === "bryan") {
    if (level === "iniciante") return 2;
    if (level === "intermediario") return 3;
    return 4;
  }
  if (kind === "bedin") {
    if (level === "iniciante") return 4;
    if (level === "intermediario") return 5;
    return 6;
  }
  if (level === "iniciante") return 4;
  if (level === "intermediario") return 6;
  return 8;
}

export function xpFor(level: Level, first: boolean, stars: number): number {
  const base = level === "iniciante" ? 40 : level === "intermediario" ? 60 : 80;
  const bonus = stars >= 3 ? 15 : stars === 2 ? 8 : 0;
  return Math.round((first ? base : base / 2) + bonus);
}

export function starsFromMisses(misses: number): number {
  if (misses <= 0) return 3;
  if (misses <= 2) return 2;
  if (misses <= 5) return 1;
  return 0;
}
