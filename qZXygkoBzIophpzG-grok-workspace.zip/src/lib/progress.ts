import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import {
  CASE_IDS,
  emptyProfile,
  type CaseId,
  type CaseProgress,
  type Level,
  type Profile,
} from "@/lib/game/types";

type ProfileRow = {
  badge_name: string;
  selected_level: string;
  xp: number;
  seen_briefing: boolean;
};

type CaseRow = {
  case_id: string;
  completed: boolean;
  stars: number;
  best_score: number;
  clue: string | null;
  attempts: number;
};

type CertRow = {
  score: number;
};

function asLevel(value: string): Level {
  if (value === "intermediario" || value === "avancado") return value;
  return "iniciante";
}

function asCaseId(value: string): CaseId | null {
  return (CASE_IDS as readonly string[]).includes(value) ? (value as CaseId) : null;
}

function assemble(profile: ProfileRow, cases: CaseRow[], cert: CertRow | undefined): Profile {
  const next = emptyProfile(profile.badge_name);
  next.level = asLevel(profile.selected_level);
  next.xp = Number(profile.xp) || 0;
  next.seenBriefing = Boolean(profile.seen_briefing);
  next.certified = Boolean(cert);
  next.certificateScore = cert ? Number(cert.score) || 0 : 0;
  for (const row of cases) {
    const id = asCaseId(row.case_id);
    if (!id) continue;
    next.cases[id] = {
      completed: Boolean(row.completed),
      stars: Number(row.stars) || 0,
      bestScore: Number(row.best_score) || 0,
      clue: row.clue,
      attempts: Number(row.attempts) || 0,
    };
  }
  return next;
}

async function readProfile(userId: string, level: Level): Promise<Profile> {
  const sql = await getSql();
  let profiles = await sql<ProfileRow>`
    select badge_name, selected_level, xp, seen_briefing
    from dlp_profiles
    where user_id = ${userId}
  `;
  if (!profiles[0]) {
    await sql`
      insert into dlp_profiles (user_id, badge_name, selected_level)
      values (${userId}, ${"Detetive"}, ${level})
    `;
    profiles = await sql<ProfileRow>`
      select badge_name, selected_level, xp, seen_briefing
      from dlp_profiles
      where user_id = ${userId}
    `;
  }
  const row = profiles[0]!;
  const selected = asLevel(row.selected_level);
  const cases = await sql<CaseRow>`
    select case_id, completed, stars, best_score, clue, attempts
    from dlp_cases
    where user_id = ${userId} and level = ${selected}
  `;
  const certs = await sql<CertRow>`
    select score from dlp_certificates
    where user_id = ${userId} and level = ${selected}
  `;
  return assemble(row, cases, certs[0]);
}

export const getProfile = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    return readProfile(context.userId, "iniciante");
  });

export const updateProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { badgeName?: string; level?: Level; seenBriefing?: boolean }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const current = await readProfile(context.userId, "iniciante");
    const badgeName = (data.badgeName ?? current.badgeName).trim().slice(0, 32) || "Detetive";
    const level = data.level ?? current.level;
    const seen = data.seenBriefing ?? current.seenBriefing;
    await sql`
      insert into dlp_profiles (user_id, badge_name, selected_level, xp, seen_briefing, updated_at)
      values (${context.userId}, ${badgeName}, ${level}, ${current.xp}, ${seen}, now())
      on conflict (user_id) do update set
        badge_name = excluded.badge_name,
        selected_level = excluded.selected_level,
        seen_briefing = excluded.seen_briefing,
        updated_at = now()
    `;
    return readProfile(context.userId, level);
  });

export const saveCaseResult = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (input: {
      caseId: CaseId;
      level: Level;
      completed: boolean;
      stars: number;
      score: number;
      clue: string;
      xpGain: number;
    }) => input,
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const current = await readProfile(context.userId, data.level);
    const prev: CaseProgress = current.cases[data.caseId];
    const stars = Math.max(prev.stars, Math.min(3, Math.max(0, data.stars)));
    const bestScore = Math.max(prev.bestScore, data.score);
    const attempts = prev.attempts + 1;
    const completed = prev.completed || data.completed;
    const clue = data.clue || prev.clue;
    const xpGain = prev.completed ? Math.min(data.xpGain, 20) : data.xpGain;
    const xp = current.xp + Math.max(0, xpGain);

    await sql`
      insert into dlp_cases (
        user_id, level, case_id, completed, stars, best_score, clue, attempts, updated_at
      )
      values (
        ${context.userId}, ${data.level}, ${data.caseId}, ${completed}, ${stars},
        ${bestScore}, ${clue}, ${attempts}, now()
      )
      on conflict (user_id, level, case_id) do update set
        completed = excluded.completed,
        stars = excluded.stars,
        best_score = excluded.best_score,
        clue = excluded.clue,
        attempts = excluded.attempts,
        updated_at = now()
    `;
    await sql`
      insert into dlp_profiles (user_id, badge_name, selected_level, xp, seen_briefing, updated_at)
      values (${context.userId}, ${current.badgeName}, ${data.level}, ${xp}, ${current.seenBriefing}, now())
      on conflict (user_id) do update set
        xp = excluded.xp,
        selected_level = excluded.selected_level,
        updated_at = now()
    `;
    return readProfile(context.userId, data.level);
  });

export const issueCertificate = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { level: Level; score: number }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`
      insert into dlp_certificates (user_id, level, score, issued_at)
      values (${context.userId}, ${data.level}, ${data.score}, now())
      on conflict (user_id, level) do update set
        score = greatest(dlp_certificates.score, excluded.score)
    `;
    return readProfile(context.userId, data.level);
  });
