import { useEffect } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useGame } from "@/store/game";
import { LoadingDossier } from "@/components/game/hub";
import { DiplomaScreen } from "@/components/game/diploma";

export const Route = createFileRoute("/diploma")({ component: DiplomaPage });

function DiplomaPage() {
  const { user, isPending } = useCurrentUserState();
  const { ready, hydrate } = useGame();

  useEffect(() => {
    if (user) void hydrate();
  }, [user, hydrate]);

  if (isPending || (user && !ready)) return <LoadingDossier />;
  if (!user) return <RedirectToSignIn />;
  return <DiplomaScreen />;
}
