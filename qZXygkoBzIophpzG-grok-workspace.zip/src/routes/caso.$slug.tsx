import { useEffect } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { CASE_IDS, type CaseId } from "@/lib/game/types";
import { useGame } from "@/store/game";
import { LoadingDossier } from "@/components/game/hub";
import { CaseAnne } from "@/components/game/case-anne";
import { CaseBryan } from "@/components/game/case-bryan";
import { CaseBedin } from "@/components/game/case-bedin";
import { CaseLivia } from "@/components/game/case-livia";
import { CaseManuella } from "@/components/game/case-manuella";
import { PaperCard, StationShell, Btn } from "@/components/game/chrome";

export const Route = createFileRoute("/caso/$slug")({ component: CasePage });

function CasePage() {
  const { slug } = Route.useParams();
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const { ready, hydrate, error } = useGame();

  useEffect(() => {
    if (user) void hydrate();
  }, [user, hydrate]);

  if (isPending) return <LoadingDossier />;
  if (!user) return <RedirectToSignIn />;
  if (!ready) return <LoadingDossier />;
  if (error === "Unauthorized") return <RedirectToSignIn />;

  if (!(CASE_IDS as readonly string[]).includes(slug)) {
    return (
      <StationShell>
        <PaperCard>
          <p className="font-display text-xl">Sala inexistente no mapa da delegacia.</p>
          <Btn className="mt-4" variant="ink" onClick={() => navigate({ to: "/" })}>
            Voltar
          </Btn>
        </PaperCard>
      </StationShell>
    );
  }

  const id = slug as CaseId;
  if (id === "anne") return <CaseAnne />;
  if (id === "bryan") return <CaseBryan />;
  if (id === "bedin") return <CaseBedin />;
  if (id === "livia") return <CaseLivia />;
  return <CaseManuella />;
}
