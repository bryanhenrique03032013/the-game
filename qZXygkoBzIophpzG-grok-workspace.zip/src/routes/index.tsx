import { useEffect } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { useGame } from "@/store/game";
import { HubScreen, LoadingDossier, TitleScreen } from "@/components/game/hub";
import { unlockAudio } from "@/lib/game/sfx";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const navigate = useNavigate();
  const { user } = useCurrentUserState();
  const { ready, hydrate, error } = useGame();

  useEffect(() => {
    if (user) void hydrate();
  }, [user, hydrate]);

  const enter = () => {
    unlockAudio();
    navigate({ to: "/login" });
  };

  if (user) {
    if (!ready) return <LoadingDossier />;
    if (error === "Unauthorized") return <TitleScreen onEnter={enter} />;
    return <HubScreen />;
  }

  return <TitleScreen onEnter={enter} />;
}
