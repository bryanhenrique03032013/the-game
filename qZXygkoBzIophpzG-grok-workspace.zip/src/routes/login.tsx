import { useState, type FormEvent } from "react";
import { createFileRoute, Navigate, useNavigate } from "@tanstack/react-router";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Btn, Field, Input, PaperCard, StationShell, Tape } from "@/components/game/chrome";
import { LoadingDossier } from "@/components/game/hub";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (isPending) return <LoadingDossier />;
  if (user) return <Navigate to="/" />;

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      if (mode === "up") {
        const res = await authClient.signUp.email({
          email,
          password,
          name: name.trim() || "Detetive",
        });
        if (res.error) throw new Error(res.error.message);
      } else {
        const res = await authClient.signIn.email({ email, password });
        if (res.error) throw new Error(res.error.message);
      }
      navigate({ to: "/" });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Não foi possível identificar o crachá.";
      setError(translateAuthError(message));
    } finally {
      setBusy(false);
    }
  }

  return (
    <StationShell>
      <Tape className="mb-8 h-6 -rotate-2" />
      <p className="font-display text-xs tracking-[0.3em] text-tape">IDENTIFIQUE-SE</p>
      <h1 className="mt-2 font-display text-4xl">Balcão da delegacia</h1>
      <p className="mt-2 max-w-md text-sm text-paper/70">
        Crie um crachá com e-mail ou entre com Google / X. O progresso das salas fica salvo na sua
        conta.
      </p>
      <PaperCard className="mt-6 max-w-md">
        {authEnabled ? (
          <>
            <div className="flex gap-2">
              {GROK_PROVIDERS.map((p) => (
                <Btn
                  key={p.providerId}
                  variant="ink"
                  className="flex-1"
                  onClick={() => signIn(p.providerId, { callbackURL: "/" })}
                >
                  {p.label}
                </Btn>
              ))}
            </div>
            <p className="my-4 text-center text-xs uppercase tracking-[0.18em] text-ink/40">
              ou e-mail da casa
            </p>
            <form className="space-y-3" onSubmit={onSubmit}>
              {mode === "up" ? (
                <Field label="Nome no crachá">
                  <Input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    autoComplete="name"
                    required
                  />
                </Field>
              ) : null}
              <Field label="E-mail">
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  autoComplete="email"
                  required
                />
              </Field>
              <Field label="Senha">
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete={mode === "up" ? "new-password" : "current-password"}
                  minLength={8}
                  required
                />
              </Field>
              {error ? <p className="text-sm text-stamp">{error}</p> : null}
              <Btn type="submit" variant="stamp" className="w-full" disabled={busy}>
                {busy ? "Conferindo…" : mode === "up" ? "Criar crachá" : "Entrar no plantão"}
              </Btn>
            </form>
            <button
              type="button"
              className="mt-4 w-full text-sm text-ink/60 underline-offset-4 hover:underline"
              onClick={() => {
                setMode(mode === "up" ? "in" : "up");
                setError(null);
              }}
            >
              {mode === "up" ? "Já tenho crachá" : "Ainda não tenho crachá"}
            </button>
          </>
        ) : (
          <p className="text-sm text-ink/60">O balcão está fechado neste plantão.</p>
        )}
      </PaperCard>
    </StationShell>
  );
}

function translateAuthError(message: string): string {
  const lower = message.toLowerCase();
  if (lower.includes("invalid") && lower.includes("password")) return "E-mail ou senha não conferem.";
  if (lower.includes("already") || lower.includes("exists")) return "Esse e-mail já tem crachá. Entre no plantão.";
  if (lower.includes("too short") || lower.includes("min")) return "A senha precisa de pelo menos 8 caracteres.";
  return message;
}
