import { create } from "zustand";
import { emptyProfile, type Profile } from "@/lib/game/types";
import { getProfile, issueCertificate, saveCaseResult, updateProfile } from "@/lib/progress";
import type { CaseId, Level } from "@/lib/game/types";

type GameStore = {
  profile: Profile;
  ready: boolean;
  error: string | null;
  hydrate: () => Promise<void>;
  setBadge: (badgeName: string) => Promise<void>;
  setLevel: (level: Level) => Promise<void>;
  markBriefing: () => Promise<void>;
  finishCase: (input: {
    caseId: CaseId;
    completed: boolean;
    stars: number;
    score: number;
    clue: string;
    xpGain: number;
  }) => Promise<void>;
  certify: (score: number) => Promise<void>;
};

export const useGame = create<GameStore>((set, get) => ({
  profile: emptyProfile(),
  ready: false,
  error: null,
  async hydrate() {
    try {
      const profile = await getProfile();
      set({ profile, ready: true, error: null });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Falha ao abrir o dossiê.";
      set({ error: message, ready: true });
    }
  },
  async setBadge(badgeName) {
    const profile = await updateProfile({ data: { badgeName } });
    set({ profile });
  },
  async setLevel(level) {
    const profile = await updateProfile({ data: { level } });
    set({ profile });
  },
  async markBriefing() {
    const profile = await updateProfile({ data: { seenBriefing: true } });
    set({ profile });
  },
  async finishCase(input) {
    const { profile } = get();
    const next = await saveCaseResult({
      data: {
        ...input,
        level: profile.level,
      },
    });
    set({ profile: next });
  },
  async certify(score) {
    const { profile } = get();
    const next = await issueCertificate({ data: { level: profile.level, score } });
    set({ profile: next });
  },
}));
